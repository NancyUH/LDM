//mongooseモジュールの読み込み
var mongoose = require('mongoose');

//ObjectIDモジュールの作成、mongoDBのオブジェクトIDを代入
exports.ObjectId = mongoose.Types.ObjectId;
//Camモジュールの作成
exports.Cam;
//Stationモジュールの作成
exports.Station;
//Routeモジュールの作成
exports.Route;
//BSDataモジュールの作成
exports.BSData;
//Cellモジュールの作成
exports.Cell;

//mongoDBへの接続ができてなかったら
if (mongoose.connection.readyState != mongoose.Connection.STATES.connected) {
  //mongoDBへの接続
  mongoose.connect('mongodb://localhost/ldm');
  console.log("connect db");
}

// Station
// Stationスキーマ作成のモジュールの作成
function initStation() {
  //mongoDBのスキーマ（構造）の新規作成
  var stationSchema = new mongoose.Schema({
    sid   : { type: Number, unique: true },
    sname : String,
  }, {collection: 'stations'});

//Stationモジュールに上記のスキーマのコンパイルメソッドを追加
  exports.Station = mongoose.model('Station', stationSchema);
}

//もしStationモジュールの中が空だったら
if (exports.Station == null) {
  //initStationを実行
  initStation();
}


// Cam
// Camスキーマ作成のモジュールの作成
function initCam() {
  //mongoDBのスキーマ（構造）の新規作成
  var camSchema = new mongoose.Schema({
    protocolVersion : Number,
    station         : {type: mongoose.Schema.Types.ObjectId, ref: 'Station'}, // station = user
    stype           : Number, // 不明（0），歩行者（1），自転車（2），原付き（3），自動二輪（4），自動車（5），バス（6），小型トラック（7），大型トラック（8），トレーラ（9），緊急車両（10），トラム（11），路側機（15）
    date            : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
    alt             : {type : Number, min: -100000, max: 800000},
    rotation        : {type : Number, min: 0, max: 3599},
    speed           : {type : Number, min: 0, max: 16382},
    direction       : {type : Number, min: 0, max: 1},
    acceleration    : {type : Number, min: -160, max: 160},
  }, {collection: 'cams'});
//Camモジュールに上記のスキーマのコンパイルメソッドを追加
  exports.Cam = mongoose.model('Cam', camSchema);
}

//もしCamモジュールの中が空だったら
if (exports.Cam == null) {
  //initCamを実行
  initCam();
}

//Routeのスキーマ作成
function initRoute(){
  //mongoDBのスキーマの（構造））の新規作成
  var routeSchema = new mongoose.Schema({
    station          : {type: mongoose.Schema.Types.ObjectId, ref: 'Station'}, // station = user
    date             : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    rid              : Number,
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
    time            : Number,
    polyline         : String,
  }, {collection: 'routes'});
    exports.Route = mongoose.model('Route',routeSchema);
}


//もしRouteモジュールの中が空だったら
if(exports.Route == null){
  //initRouteを実行
  initRoute();
}

//BSDataのスキーマ作成
function initBaseStation(){
  //mongoDBのスキーマの（構造））の新規作成
  var BSDataSchema = new mongoose.Schema({
    BSid             : Number,
    date            : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
  }, {collection: 'BSdata'});
    exports.BSData = mongoose.model('BSData',BSDataSchema);
}


//もしBSDataモジュールの中が空だったら
if(exports.BSData == null){
  //initBaseStationを実行
  initBaseStation();
}

function initCell(){
  //mongoDBのスキーマの（構造））の新規作成
  var CellSchema = new mongoose.Schema({
    BSdata             : {type: mongoose.Schema.Types.ObjectId, ref: 'BSData'},
    BSid : Number,
    date            : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    radius        : Number,
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
  }, {collection: 'cells'});
    exports.Cell = mongoose.model('Cell',CellSchema);
}

if(exports.Cell == null){
  //initCellを実行
  initCell();
}

