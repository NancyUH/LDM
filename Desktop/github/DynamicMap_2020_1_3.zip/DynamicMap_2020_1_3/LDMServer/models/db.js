//mongooseモジュールの読み込み
var mongoose = require('mongoose');

//ObjectIDモジュールの作成、mongoDBのオブジェクトIDを代入
exports.ObjectId = mongoose.Types.ObjectId;
//Camモジュールの作成
exports.Cam;
//Stationモジュールの作成
exports.Station;
//Roadpathモジュールの作成
exports.Roadpath;
//Cmapモジュールの作成
exports.Cmap;
//DtBSモジュールの作成
exports.DtBS;

//mongoDBへの接続ができてなかったら
if (mongoose.connection.readyState != mongoose.Connection.STATES.connected) {
  //mongoDBへの接続
  mongoose.connect('mongodb://localhost/ldm');
  console.log("connect db");
}

// Station
// Stationスキーマ作成のモジュールの作成
function initStation() {
  //mongoDBのスキーマ（構造）の新規作成
  var stationSchema = new mongoose.Schema({
    sid   : { type: Number, unique: true },
    sname : String,
  }, {collection: 'stations'});

//Stationモジュールに上記のスキーマのコンパイルメソッドを追加
  exports.Station = mongoose.model('Station', stationSchema);
}

//もしStationモジュールの中が空だったら
if (exports.Station == null) {
  //initStationを実行
  initStation();
}


// Cam
// Camスキーマ作成のモジュールの作成
function initCam() {
  //mongoDBのスキーマ（構造）の新規作成
  var camSchema = new mongoose.Schema({
    protocolVersion : Number,
    station         : {type: mongoose.Schema.Types.ObjectId, ref: 'Station'}, // station = user
    stype           : Number, // 不明（0），歩行者（1），自転車（2），原付き（3），自動二輪（4），自動車（5），バス（6），小型トラック（7），大型トラック（8），トレーラ（9），緊急車両（10），トラム（11），路側機（15）
    date            : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
    alt             : {type : Number, min: -100000, max: 800000},
    rotation        : {type : Number, min: 0, max: 3599},
    speed           : {type : Number, min: 0, max: 16382},
    direction       : {type : Number, min: 0, max: 1},
    acceleration    : {type : Number, min: -160, max: 160},
  }, {collection: 'cams'});
//Camモジュールに上記のスキーマのコンパイルメソッドを追加
  exports.Cam = mongoose.model('Cam', camSchema);
}

//もしCamモジュールの中が空だったら
if (exports.Cam == null) {
  //initCamを実行
  initCam();
}

//RoadPathのスキーマ作成
function initRoad(){
  //mongoDBのスキーマの（構造））の新規作成
  var roadSchema = new mongoose.Schema({
    station          : {type: mongoose.Schema.Types.ObjectId, ref: 'Station'}, // station = user
    sid              : Number,
    date             : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    rid              : Number,
    slat             : {type : Number, min: -900000000, max: 900000000},
    slng             : {type : Number, min: -1800000000, max: 1800000000},
    glat             : {type : Number, min: -900000000, max: 900000000},
    glng             : {type : Number, min: -1800000000, max: 1800000000},
    stime            : Number,
    gtime            : Number,
    polyline         : String,
  }, {collection: 'roads'});
    exports.Roadpath = mongoose.model('Roadpath',roadSchema);
}


//もしRoadPathモジュールの中が空だったら
if(exports.Roadpath == null){
  //initRoadを実行
  initRoad();
}

//RoadPathのスキーマ作成
function initConnectionmap(){
  //mongoDBのスキーマの（構造））の新規作成
  var CmapSchema = new mongoose.Schema({
    cid             : Number,
    date            : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
   // distance        : Number,
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
  }, {collection: 'cmap'});
    exports.Cmap = mongoose.model('Cmap',CmapSchema);
}


//もしRoadPathモジュールの中が空だったら
if(exports.Cmap == null){
  //initRoadを実行
  initConnectionmap();
}

function initDistancetoBS(){
  //mongoDBのスキーマの（構造））の新規作成
  var DtBSSchema = new mongoose.Schema({
    cid             : Number,
    date            : {type : Date, default: Date.now, required: 'Must have start date - default value is the created date'},
    distance        : Number,
    lat             : {type : Number, min: -900000000, max: 900000000},
    lng             : {type : Number, min: -1800000000, max: 1800000000},
  }, {collection: 'dtbs'});
    exports.DtBS = mongoose.model('DtBS',DtBSSchema);
}

if(exports.DtBS == null){
  //initRoadを実行
  initDistancetoBS();
}

