#! /usr/bin/env python
# -*- coding: utf-8 -*-
#stepの情報を送る順番に並べ直してURLにアップロードする
import os
import os.path
import math
import requests
import datetime
from collections import Counter
from time import sleep

HOSTNAME  = "localhost"
# HOSTNAME  = "210.140.85.188"
PORT      = "3000"
# PORT      = "80"
URL       = "http://" + HOSTNAME + ":" + PORT + "/api/cam/create"
URL2      = "http://" + HOSTNAME + ":" + PORT + "/api/roadpath/create"

DIR_PATH  = './GoogleDirectionData'
DIR_PATH2 = './GoogleRoadData'
DIR_PATH3 = './GoogleConnectData'
# リアルタイムにデータを送信する
# Trueの場合、現在時刻で、1秒ごとにデータを送信する
# Falseの場合、BASE_TIMEを基準にデータを送信する
IS_REALTIME = True
BASE_TIME = "2016-02-13T02:30:00.000"
#BASE_TIME = "2019-11-01T17:30:00.000"

def uploadCam():
    #日付時間等の文字列情報を日付時間として認識できるように変換する
    baseDate = datetime.datetime.strptime(BASE_TIME, "%Y-%m-%dT%H:%M:%S.%f")
    #fileNamesにDIRPATH(./GoogleDirectionData)下の一覧を取得する
    #fileNames -> 0001.txt, 0002.txt...
    fileNames = os.listdir(DIR_PATH)
    #print("fileNames="+str(fileNames))

    timeDic = {}

    #fileNameを一つづつ見る
    for fileName in fileNames:
        #print("fileName"+str(fileName))
        #もし、fileNameの拡張子が.txtではなかったら飛ばす
        if not fileName.endswith(".txt"):
            continue

        #sidに.txtを消した整数つまり1等のid情報を入れる（00部分は消えている)
        sid = int(fileName.replace('.txt', ''))
        #print("sid="+str(sid))

        #fileNameのファイルを開く
        f = open(DIR_PATH + '/' + fileName)
        #1行ごとに見る（行の情報はlineに）
        lines = f.readlines()
        #enurate()インデックス番号をつける-> timeにはインデックス番号　lineに行情報が入る形
        #print("------------sid="+str(sid)+"------------")
        for time, line in enumerate(lines):
            #改行コードをなくす
            line = line.replace('\n', '')
            #print(str(time)+":"+str(line))
            #タブコードで区切って中身を配列paramsに入れる
            #params[0] :緯度 params[1]:経度 params[2]:向きの変化　params[3]:速度
            params = line.split('\t')

            lat      = int(params[0])
            lng      = int(params[1])
            rotation = int(params[2])
            speed    = int(params[3])

            #上記の情報をstepに入れつつ他の情報も追加
            step = {
                    'sid'             : sid,    #1,2
                    'lat'             : lat,    #緯度
                    'lng'             : lng,    #経度
                    'protocolVersion' : 1,      #プロトコルバージョン
                    'stype'           : 5,      #種類（歩行者、自動車、緊急車両...)
                    'alt'             : 0,      #高度
                    'rotation'        : rotation,
                    'speed'           : speed,
                    'direction'       : 0,
                    'acceleration'    : 0,
            }

            #リアルタイムでない場合
            if not IS_REALTIME:
                #baseDateにこのfor文で回した回数分（time)（結局は経路の経過時間になる）を加えたものをtmpDateに入れる
                tmpDate  = baseDate + datetime.timedelta(seconds = time)
                #日付時間等の情報を文字列の形で変換したものをdateDtrに入れる
                dateStr  = tmpDate.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
                #stepにdate : dateStrを加える
                step['date'] = dateStr
            #keyにtime(経路の経過時間)を10桁で書かれたものを代入（00000000001)
            key = "%010d" % time
            #key = time
            #print("key="+str(key))

            
            #timeDic内にkeyがなかったら
            if not key in timeDic:
                #timeDicの中にtimeDic[key]を作りその中にNULLを入れる
                timeDic[key] = []
            #配列stepsにtimeDic[key]の中身を入れる
            steps = timeDic[key]
            #print("time"+str(timeDic))
            #そこにstepの情報をを追加(中身が入ってたときのため)
            steps.append(step)
            #更新された情報(steps)を再びtimeDic[key]に入れる
            timeDic[key] = steps
    #経過時間で回す
    for time in sorted(timeDic):
        #sidで回す
        for step in timeDic[time]:
            #URLにstepをリクエスト送信する
            res = requests.post(URL, data=step)
            #print ("uploaded: %d\t%d\t%d" % (step['sid'], step['lat'], step['lng']))

        if IS_REALTIME :
           sleep(1)


    #print ('uploaded:all')

def uploadRoad():
    fileNames = os.listdir(DIR_PATH2)
    #print("fileNames="+str(fileNames))
    nodeDic = {}

    #fileNameを一つづつ見る
    for fileName in fileNames:
        #print("fileName"+str(fileName))
        #もし、fileNameの拡張子が.txtではなかったら飛ばす
        if not fileName.endswith(".txt"):
            continue

        #sidに.txtを消した整数つまり1等のid情報を入れる（00部分は消えている)
        sid = int(fileName.replace('.txt', ''))
        #print("sid="+str(sid))

        #fileNameのファイルを開く
        f = open(DIR_PATH2 + '/' + fileName)
        #1行ごとに見る（行の情報はlineに）
        lines = f.readlines()
        #enurate()インデックス番号をつける-> timeにはインデックス番号　lineに行情報が入る形
        #print("------------sid="+str(sid)+"------------")
        for time, line in enumerate(lines):
            #改行コードをなくす
            line = line.replace('\n', '')
            #print(str(time)+":"+str(line))
            #タブコードで区切って中身を配列paramsに入れる
            #params[0] :緯度 params[1]:経度 params[2]:向きの変化　params[3]:速度
            params = line.split('\t')

            rid      = int(params[0])
            slat     = int(params[1])
            slng     = int(params[2])
            glat     = int(params[3])
            glng     = int(params[4])
            stime    = int(params[5])
            gtime    = int(params[6])
            polyline = params[7]

            #上記の情報をstepに入れつつ他の情報も追加
            node = {
                    'sid'             : sid,    
                    'rid'             : rid,
                    'slat'            : slat,    
                    'slng'            : slng,    
                    'glat'            : glat,      
                    'glng'            : glng,  
                    'stime'           : stime,
                    'gtime'           : gtime,  
                    'polyline'        : polyline,
            }

            #keyにtime(経路の経過時間)を10桁で書かれたものを代入（00000000001)
            key = "%010d" % time
            #key = time
            #print("key="+str(key))

            
            #timeDic内にkeyがなかったら
            if not key in nodeDic:
                #timeDicの中にtimeDic[key]を作りその中にNULLを入れる
                nodeDic[key] = []
            #配列stepsにtimeDic[key]の中身を入れる
            nodes = nodeDic[key]
            #print("time"+str(nodeDic))
            #そこにstepの情報をを追加(中身が入ってたときのため)
            nodes.append(node)
            #更新された情報(nodes)を再びtimeDic[key]に入れる
            nodeDic[key] = nodes
    #経過時間で回す
    for time in sorted(nodeDic):
        #sidで回す
        for node in nodeDic[time]:
            #URLにstepをリクエスト送信する
            res = requests.post(URL2, data=node)
            print ("uploaded: %d\t%d\t%d\t%d\t%s" % (node['sid'], node['rid'], node['slat'],node['slng'],node['polyline']))

        if IS_REALTIME :
           sleep(1)

    #print ('uploaded:all')

def main():
    uploadRoad()
    uploadCam()

if __name__ == '__main__':
    main()

