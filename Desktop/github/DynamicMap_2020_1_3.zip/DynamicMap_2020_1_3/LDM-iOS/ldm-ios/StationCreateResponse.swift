//
//  StationCreateResponse.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/30.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import ObjectMapper

class StationCreateResponse: Mappable {
    var success:Bool = false
    var sid:Int = 0
    
    required init(){}
    required init?(map: Map){}
    func mapping(map: Map) {
        success <- map["success"]
        sid <- map["sid"]
    }
}
