//
//  Util.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/27.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import UIKit
import SwiftyUserDefaults

/* Log */
func LOG(_ body: Any = "", function: String = #function, line: Int = #line) {
    print("[\(function) : \(line)] \(body)")
}

func LOGRect(_ rect: CGRect) {
    print(NSStringFromCGRect(rect))
}

func LOGSize(_ size: CGSize) {
    print(NSStringFromCGSize(size))
}

func LOGPoint(_ point: CGPoint) {
    print(NSStringFromCGPoint(point))
}
