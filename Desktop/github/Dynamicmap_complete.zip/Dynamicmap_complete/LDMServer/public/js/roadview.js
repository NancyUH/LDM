var map;
var stationDic = {};
var roadDic = {};
var maxLat =  -90.0;
var minLat =   90.0;
var maxLng = -180.0;
var minLng =  180.0;
var isInited = false;
var tLat, tLng;
var alertStations     = [];
var dangerousStations = [];
var useCentralMode = true;
var alertCircle = null;
var useAlertCircle = true;
var timeDic = {}

//api.jsのcam情報を使う
//cam情報からのマーカーの作成とstationDicの'maker'の登録、警告の処理
function displayMarker(cam) {
  var sid    = cam.station.sid
  var key    = String(sid);
  var marker = null;
  if(key in timeDic){

  }else{
    timeDic[key] = cam.date;
  }
  
　//stationDic内にkeyがあり、かつStationDic[key]内に'maker'がある場合
  if (key in stationDic && 'marker' in stationDic[key]) {
    //makerにstationDic[key]['maker']情報を入れる
    marker = stationDic[key]['marker'];
  } else {
    //makerにstationDic[key]にcamを入れる
    stationDic[key] = cam;
    //マーカーアイコン(オブジェクト）の作成(commmn.jsのmakeMaker)
    //mapは初期はcommon.jsのinitMapで設定
    marker = makeMarker(map, sid, cam.stype, cam.lat, cam.lng);
  }

  // 距離を算出し、アラートを出す
  //isAlertMode->route/index.jsのパラメータ
  if (isAlertMode) {
    //tid->route/index.jsのパラメータ
    //camのidとパラメータのidが同じなら
    if (sid == tid) {
      //tLat,tLngにそれぞれcamの緯度経度を代入
      tLat = cam.lat;
      tLng = cam.lng;
      //tLatLngオブジェクトを作る
      var tLatLng = new google.maps.LatLng(tLat, tLng);
      // 中心モードの場合は、地図の中心を更新
      // setCenterを使うとマーカーが途中から消えるバグがあるので注意
      // https://code.google.com/p/gmaps-api-issues/issues/detail?id=5716
      //presemt.ectの中心表示モードがONになってるとき
      if (useCentralMode) {
        //地図の中央に表示、位置座標を絶対的に移動させる（中央表示）
        map.panTo(tLatLng);
      }
      // 警告範囲の表示
      //presemt.ectの警告範囲の表示がONになってるとき
      if (useAlertCircle) {
        //alertCircleがnull(初期)のとき
        if (alertCircle == null) {
          //makrAlertCircle(common.js)を呼び出す
          //円の作成
          alertCircle = makeAlertCircle(map);
        }
        //円の中心の座標の設定
        alertCircle.setCenter(tLatLng);
      } else {
        //警告範囲の表示がoffの時は経度緯度が0,0のところを中心にする
        alertCircle.setCenter(new google.maps.LatLng(0, 0));
      }
    //camのidとパラメータのidが違う時
    } else {
      // camのidとパラメーターのidとの距離を算出し、必要に応じてアラートを出す
      // アラートを出す必要がない場合は、リストから消す
      //handlealert->commmon.js
      //isAlertの設定もあり
      handleAlert(sid, cam.lat, cam.lng, tLat, tLng, alertStations, dangerousStations);
    }
  }
　//maker内のiconの更新（警告時や通常時、タイプ)
//common.jsにある
  setIconForMarker(marker, cam.stype, cam.lat, cam.lng, cam.rotation, cam.speed);
  //stationDic[key]['marker']にmarkerを入れる（新規作成or更新）
  stationDic[key]['marker'] = marker; // dicに格納
}
/*
cam
      'protocolVersion' : parseInt(req.body.protocolVersion),
      'station'         : station,
      'lat'             : parseInt(req.body.lat),
      'lng'             : parseInt(req.body.lng),
      'rotation'        : parseInt(req.body.rotation),
      'speed'           : parseInt(req.body.speed),
      'stype'           : parseInt(req.body.stype),
      'date'            : (req.body.date) ? req.body.date : Date.now(),
      'alt'             : (req.body.alt) ? parseInt(req.body.alt) : 0,
      'direction'       : (req.body.direction) ? parseInt(req.body.direction) : 0,
      'acceleration'    : (req.body.acceleration) ? parseInt(req.body.acceleration) : 0,
new-> 'marker'          : 
*/
/*
stationDic-key(sid)　　　　　-cam
　　　　　　↓IDの数分増えていく
*/

function updateCornerLatLng(cam) {
  //はみ出し防止
  if (cam.lat > maxLat) maxLat = cam.lat;
  if (cam.lat < minLat) minLat = cam.lat;
  if (cam.lng > maxLng) maxLng = cam.lng;
  if (cam.lng < minLng) minLng = cam.lng;
}


function displayRoads(){
  
  $.getJSON("/api/allroadpath/fetch", function(_json) {
    //jsonにはcam情報が入る
    json       = _json;
    for(var i = 0; i < json.length; i++){
      var dsid = json[i]['sid'];
      var drid = json[i]['rid'];
      var convertedslat = json[i]['slat'] / Math.pow(10, 6);
      var convertedslng = json[i]['slng'] / Math.pow(10, 6);
      var convertedglat = json[i]['glat'] / Math.pow(10, 6);
      var convertedglng = json[i]['glng'] / Math.pow(10, 6);
      var stime = json[i]['stime'];
      var gtime = json[i]['gtime'];
      var ddate = new Date(json[i]['date']);
      var encoded_path = json[i]['polyline'];
      var decoded_path = google.maps.geometry.encoding.decodePath(encoded_path);
      ddate.setSeconds(ddate.getSeconds()+stime);
      var sdate = ddate;
      ddate = new Date(json[i]['date']);
      ddate.setSeconds(ddate.getSeconds()+gtime);
      var gdate = ddate;
      makeRmarker(dsid,drid,convertedslat,convertedslng,convertedglat,convertedglng,decoded_path,sdate,gdate,stime,gtime);
    }    
    
  });
}

function makeRmarker(sid,rid,slat,slng,glat,glng,path,sdate,gdate,stime,gtime){
  var smarker = null;
  var gmarker = null;
  var sinfoWindow = null;
  var ginfoWindow = null;
  var polyline = null;
  var key = String(sid);
  var rkey = String(rid);
  var sddate = sdate;
  var gddate = gdate;
  if(key in roadDic){
    if(rkey in roadDic[key]){
    }else{
      roadDic[key][rkey] = {};
    }
  }else{
    roadDic[key] = {};
    roadDic[key][rkey] = {};
  }
  /*
  if(Object.keys(timeDic).indexOf(key) !== -1){
    console.log(timeDic[key]);
    var ctime = new Date(timeDic[key]);
    ctime.setSeconds(ctime.getSeconds()+stime);
    sddate = ctime;
    var ctime = new Date(timeDic[key]);
    ctime.setSeconds(ctime.getSeconds()+gtime);
    gddate = ctime;

  }else
  */
  var smarkerPosition ={lat:slat,lng:slng};
  var gmarkerPosition ={lat:glat,lng:glng};
  var scontentStr = '<p>ステーションID : '+ sid +'</br>パスID : '+rid+'</br>到着時刻 : '+sddate+'</p>';
  var gcontentStr = '<p>ステーションID : '+ sid +'</br>パスID : '+rid+'</br>到着時刻 : '+gddate+'</p>';
  smarker = new google.maps.Marker({
    position  : smarkerPosition,
    map       : map,
  });
  sinfoWindow = new google.maps.InfoWindow({
    content : scontentStr
  });
  smarker.addListener('click',function(){
    sinfoWindow.open(map, smarker);
  });
  gmarker = new google.maps.Marker({
    position  : gmarkerPosition,
    map       : map,
  });
  ginfoWindow = new google.maps.InfoWindow({
    content : gcontentStr
  });
  gmarker.addListener('click',function(){
    ginfoWindow.open(map, gmarker);
  });
  var polyOptions = 
    {
        path: path , 
        strokeColor: "#ff00ff" , //線色
        strokeOpacity: 0.7 , //透明度0.0-1.0 
        strokeWeight: 10 ,//幅pixel 
        map: map
    }
  polyline = new google.maps.Polyline(polyOptions);
  polyline.setMap(map);
  roadDic[key][rkey]['smarker'] = smarker; // dicに格納
  roadDic[key][rkey]['gmarker'] = gmarker;
  //console.log(roadDic[key][rkey]['smarker']);
  roadDic[key][rkey]['sinfoWindow'] = sinfoWindow;
  roadDic[key][rkey]['ginfoWindow'] = ginfoWindow;
  roadDic[key][rkey]['polyline'] = polyline;
  //console.log(roadDic);
  //console.log(roadDic[key]);
  
}
/*
function mixroad(cam){
  var csid = cam.station.sid;
  var clat = cam.clat;
  var clng = cam.clng;
  for(var i = 0; i < json.length; i++){
    var psid = json[i]['sid'];
    if(psid == csid){
      var prid = json[i]['rid'];
      var convertedslat = json[i]['slat'] / Math.pow(10, 6);
      var convertedslng = json[i]['slng'] / Math.pow(10, 6);
      var convertedglat = json[i]['glat'] / Math.pow(10, 6);
      var convertedglng = json[i]['glng'] / Math.pow(10, 6);
      var encoded_path = json[i]['polyline'];
      var decoded_path = google.maps.geometry.encoding.decodePath(encoded_path);
    }
  }    

}
*/

$(function(){
  // 警告モードの場合はデフォルトOFF
  //表示ステーション　"すべて"をOFF
  if (isAlertMode) {
    $('#all-check').prop('checked', false);
  }
  var socket = io.connect();
  //画面更新(api.js)
  socket.on('update', function(cam){

    var sid = cam.station.sid;

    //sidがstationDicにある時
    // 凡例表示
    if (!(sid in stationDic)) {
      // 警告モードでかつ、ターゲットステーションの場合は、別表示にする
      if (isAlertMode && sid == tid) {
        //common.js target-stationの表示と更新（colorがない?)
        addTargetStationElem(cam.station.sname, cam.stype, sid);
      } else {
        // 凡例チェックボックス
        // 警告モードの場合は全てチェックを外す(警告対象にする)(colorがない？)
        addCheckboxElem(cam.station.sname, cam.stype, sid, !isAlertMode);
      }
    }
    
    //cam情報からのマーカーの作成とstationDicの'maker'の登録、警告の処理
    displayMarker(cam);
    //はみ出し防止
    updateCornerLatLng(cam);
    //警告モードの時
    if (isAlertMode) {
      // アラートを表示する(common.js)
      displayAlert(alertStations);
    }

    // 初回のみ地図の位置とズームの自動調整
    if (!isInited) {
      //マップの境界の設定とその境界がうまく写るように設定(common.js)
      fitBoundsForMap(map, minLat, maxLat, minLng, maxLng);
      isInited = true;
    }
    // TODO 一定期間動かないマーカーについては消す？
  });
});
//地図描画の実行(initMap(commomn.js)の呼び出し)
google.maps.event.addDomListener(window, 'load', initMap);

//use-central-mode(roadview.ect)が変化するたび発生するイベント
$('#use-central-mode').on("change", function() {
  useCentralMode = $(this).is(':checked');
  if (useCentralMode) {
    map.setZoom(MAX_ZOOM_LEVEL);
  } else {
    fitBoundsForMap(map, minLat, maxLat, minLng, maxLng);
  }
});

//use-alert-circle(roadview.ect)が変化するたび発生するイベント
$('#use-alert-circle').on("change", function() {
  useAlertCircle = $(this).is(':checked');
});

//refresh(roadview.ect)がクリックするたび発生するイベント
// 地図の位置とズームの自動調整
$("#refresh").on("click", function(){
  fitBoundsForMap(map, minLat, maxLat, minLng, maxLng);
});

//idのチェックボックスが変わるたびに発生するイベント
//id属性がcheckbox-と先頭一致
//https://qiita.com/Thought_Nibbler/items/5d4fc40a4d4325128b24
$(document).on("change", "[id^=checkbox-]", function() {
  //指定したidのマーカーを地図に配置
  setMapForMarker(stationDic, $(this).attr('sid'));
});

