#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os
import os.path
import requests
import csv
import json
import datetime

HOSTNAME  = "localhost"
# HOSTNAME  = "210.140.85.188"
PORT      = "3000"
# PORT      = "80"

FILE_PATH = "./keihanna.tsv"
URL       = "http://" + HOSTNAME + ":" + PORT + "/api/cam/create"
BASE_TIME = "2016-01-01T00:00:00.000"

def uploadCam():
    baseDate = datetime.datetime.strptime(BASE_TIME, "%Y-%m-%dT%H:%M:%S.%f")

    rows = csv.DictReader(open(FILE_PATH), delimiter = '\t')
    for i, row in enumerate(rows):
        for key in ['protocolVersion', 'sid', 'stype', 'lat', 'lng', 'alt', 'rotation', 'speed', 'date']:
            row[key] = int(row[key])

        tmpDate = baseDate + datetime.timedelta(milliseconds = row['date'])
        row['date'] = tmpDate.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]

        row['acceleration'] = 0
        row['direction'] = 0

        res = requests.post(URL, data=row)

    print 'uploaded:cam'

if __name__ == '__main__':
    uploadCam()

