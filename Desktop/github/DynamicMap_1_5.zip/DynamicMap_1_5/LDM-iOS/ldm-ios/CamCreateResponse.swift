//
//  CamCreateResponse.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/30.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import ObjectMapper

class CamCreateResponse: Mappable {
    var success:Bool = false
    var cid:Int = 0
    
    required init(){}
    required init?(map: Map){}
    func mapping(map: Map) {
        success <- map["success"]
        cid <- map["cid"]
    }
}
