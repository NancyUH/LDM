//
//  ViewManager.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/27.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import UIKit

struct ViewManager {
    
    static let kRootViewController = UIApplication.shared.keyWindow?.rootViewController
    
    static var kCurrentWindow: UIWindow? {
        if let window = UIApplication.shared.keyWindow {
            return window
        } else {
            return UIApplication.shared.windows[0]
        }
    }
    
    static let kStatusBarHeight = UIApplication.shared.statusBarFrame.size.height
    
    // デフォルトFloat(44)としてUnwrap
    static func kNavigationBarHeight(_ callFrom: UIViewController) -> CGFloat {
        return callFrom.navigationController?.navigationBar.frame.size.height ?? 44
    }
    
    static let kScreenBounds = UIScreen.main.bounds
    static let kScreenWidth = UIScreen.main.bounds.width
    static let kScreenHeight = UIScreen.main.bounds.height
    
    static func kContentHeight(_ callFrom: UIViewController) -> CGFloat {
        return kScreenHeight - kStatusBarHeight - self.kNavigationBarHeight(callFrom)
    }
}
