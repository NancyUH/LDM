//
//  UIViewController+Layout.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/27.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import UIKit

extension UIViewController {
    func height() -> CGFloat {
        return self.navigationController!.navigationBar.frame.size.height
    }
    
    
    var kNavogationHeight2: CGFloat {
        return height()
    }
}
