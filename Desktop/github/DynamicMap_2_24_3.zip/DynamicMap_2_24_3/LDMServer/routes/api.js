
//express,db,cam_model,binのモジュールの読み込み
var Express = require('express'),
    DB      = require('../models/db'),
    Cam     = require('../models/cam_model'),
    WWW     = require('../bin/www');

//ルーティングシステムの利用
var router = Express.Router();
var rcnt = 0;
var BScnt = 0;
var bcnt = 0;
var camcnt = 0;

var ACCEPTABLE_DIFF_SECONDS = 5; // リアルタイム描画用

/* ステーション登録 */
// curl -X POST -d "sname"="UserA" 'http://localhost:3000/api/station/create'
// curl -X POST -d "sname"="UserA" -d "sid"=15 'http://localhost:3000/api/station/create'

//ステーション登録（POST）の際に与えられたパラメータを読みこみ以下の処理をする
router.post('/station/create', function(req, res, next) {
  //postのsid値を取得
  var sid    = req.body.sid;
  //postのsname値を取得
  var sname  = req.body.sname;
  //filterの定義
  var filter = {};
  // paramsの'sname'を作る
  var params = {'sname' : sname};

  //stationの更新（db.js)
  function updateStation() {
    //filterとparamsの値をDB上で更新
    DB.Station.update(filter, params, {upsert: true}, function(err, result) {
      if (err) {
        return res.json({'success': false});
      }
      res.json({
        'success' : true,
        'sid'     : filter.sid,
      });
    });
  }

  
  if (sid) { // sidが指定された場合（パラメータにあったら）
    //filterのsidに代入
    filter['sid'] = parseInt(sid);
    //paramsのsidに代入
    params['sid'] = parseInt(sid);
    //filterとparamsの値をDB上で更新
    updateStation();
  } else {//sidが指定されなかったとき
    //コールバック関数
    var callback = function(err, station) {
      //stationにsidの最大値を持つデータを入れる
      if (err) {
        return res.json({'success': false});
      }
      // 初回は0スタート、次回以降は最大値+1
      var sid = 0;
      //stationが存在していたら
      if (station) {
        //stationのid(最大値）の値に１加える（新しいid)
        sid = station.sid + 1;
      }
      //filterとparamsのidを更新
      filter['sid'] = parseInt(sid);
      params['sid'] = parseInt(sid);
      updateStation();
    };
    // sidの最大値を持つデータの取得
    DB.Station.findOne({}, {}, {sort:{sid: -1}}, callback);
  }
});

/* Camデータの登録（MongoDBのREST APIでも可） */
// 過去のデータ
// curl -X POST -d "protocolVersion"=1 -d "stype"=1 -d "date"="2016-01-01T00:00:00.000Z" -d "lat"=347999580 -d "lng"=1357737990 -d "alt"=1 -d "rotation"=450 -d "speed"=10 -d "sid"=0 'http://localhost:3000/api/cam/create'
// 現在のデータ (dateがない場合は現在時刻を挿入する)
// curl -X POST -d "protocolVersion"=1 -d "stype"=1 -d "lat"=34799958 -d "lng"=135773799 -d "alt"=1 -d "rotation"=450 -d "speed"=10 -d "sid"=0 'http://localhost:3000/api/cam/create'
router.post('/cam/create', function(req, res, next) {
  //callback処理（stationにはrequestのidのステーションが入る）
  //リクエストで受けたidのステーションを作成（更新）し、Viewerの画面の更新を行う
  var callback = function(err, station) {
    //エラー処理
    if(err) {
      res.json({
        'success' : false,
      });
      return;
    }
    //stationがなかったら
    if (!station) {
      //sidがPOSTで得られた値、snameが何もなしで新しく作成
      station = new DB.Station({"sid":req.body.sid, "sname":""})
      camcnt++;
      //stationをDBに追加
      station.save(function(err){
        if (err) { console.log(err); }
      });
    }
    //大体requestで受け取った値
    var params = {
      'protocolVersion' : parseInt(req.body.protocolVersion),
      'station'         : station,
      'lat'             : parseInt(req.body.lat),
      'lng'             : parseInt(req.body.lng),
      'rotation'        : parseInt(req.body.rotation),
      'speed'           : parseInt(req.body.speed),
      'stype'           : parseInt(req.body.stype),
      'date'            : (req.body.date) ? req.body.date : Date.now(),
      'alt'             : (req.body.alt) ? parseInt(req.body.alt) : 0,
      'direction'       : (req.body.direction) ? parseInt(req.body.direction) : 0,
      'acceleration'    : (req.body.acceleration) ? parseInt(req.body.acceleration) : 0,
    };
    //paramsでCamデータベースのオブジェクトを作成
    var cam = new DB.Cam(params);
    //camを以下の状態にしてDBにアップする
    cam.save(function(err) {
      if(err) {
        console.log(err);
        res.json({
          'success' : false,
        });
      } else {
        // 現在時刻に近いデータの場合は、/present 画面を更新する。
        var diffSeconds = (Date.now() - cam.date.getTime()) / 1000;
        if (diffSeconds < ACCEPTABLE_DIFF_SECONDS && WWW.socket) {
          // ステーション名がない場合には、ステーション名をIDにする
          if (station.sname == null || station.sname.length == 0) {
            station.sname = "ID:" + String(station.sid);
            params['station'] = station
          }
          params['lat']      /= Math.pow(10, 6); //10^6で割る
          params['lng']      /= Math.pow(10, 6);
          params['speed']     = params['speed'] * 60 * 60/ (100 * 1000); // cm/sec -> km/hour
          params['rotation'] /= 10;//10で割る
/*以下複数ユーザへのブロードキャスト設定*/
          //WWW.socket.emit('update', params); これがデフォルト
          WWW.socket.broadcast.emit('update', params);
          WWW.socket.emit('update', params);
/*以上*/
        }

        res.json({
          'success' : true,
          'BSid'     : cam._id,
        });
      }
    });
  };
　//requestのidのstationを見つける
  DB.Station.findOne({"sid" : req.body.sid}, callback);
});

/*
router.get('/camtime/fetch', function(req, res, next) {
  var callback = function(err, cams) {
    
    if(err) {
      console.log(err);
    }
    res.json(cams);
  };
 //時刻に基づくRoute情報の検索
  Cam.selectAll(0,camcnt, callback);;
});
*/

/* Camデータの参照 */
// curl 'http://localhost:3000/api/cam/fetch?from=2015-12-30T00:00:00.000Z&to=2016-12-30T00:00:00.000Z'
router.get('/cam/fetch', function(req, res, next) {
  //パラメータの代入（空白を＋に置き換える）
  from = req.query.from.replace(' ', '+');
  to   = req.query.to.replace(' ', '+');
 //パラメータで与えられた時刻情報を元にCam情報を検索後
 //以下の処理を実行（callback)
 //検索して出て来た Cam(複数)は引数のcamsに入っている
  var callback = function(err, cams) {
    if(err) {
      console.log(err);
    }
    //結果は以下の形式で返す
    results = {
      'maxLat'      :  -90.0,
      'minLat'      :   90.0,
      'maxLng'      : -180.0,
      'minLng'      :  180.0,
      'maxUnixTime' : 0,
      'minUnixTime' : Number.MAX_VALUE,
      'stations'    : {},
    };
    //検索して出て来た各Camに対して以下の処理を実行
    cams.forEach(function(cam) {
      dic = {}
      var convertedLat      = cam.lat / Math.pow(10, 6);//10^6で割る
      var convertedLng      = cam.lng / Math.pow(10, 6);
      var convertedRotation = cam.rotation / 10;//10で割る
      var convertedSpeed    = cam.speed * 60 * 60/ (100 * 1000); // cm/sec -> km/hour;
      var unixTime          = Math.floor(cam.date.getTime());//Math.floor->引数で与えられた数以下の最大の整数を返す(小数->整数)
      //getTime->1970年1月1日0時0分0秒(UTC)を起点とした経過ミリ秒という数値で返す
      //時間を経過msでunixTimeに入れる

      var station = cam.station;
      var sid     = station.sid;
　　　　//result['stations']（返す結果）の中にsidがあったら
      if(sid in results['stations']) {
        //result['stations'][sid]の中身をdicに代入
        dic = results['stations'][sid]
      } else {
        //result['stations']のなかにsidがなかったら
        //dicに以下を代入
        dic = {
          'station'         : station,
          'stype'           : cam.stype,
          'protocolVersion' : cam.protocolVersion,
          'steps'           : [],
        }
        // ステーション名がない場合には、IDをステーション名にする
        if (station.sname == null || station.sname.length == 0) {
          station.sname = "ID:" + String(station.sid);
          dic['station'] = station
        }
      }
      //dic[steps]に以下を入れる
      dic['steps'].push({
        'date'     : cam.date,
        'unixTime' : unixTime,
        'lat'      : convertedLat,
        'lng'      : convertedLng,
        'rotation' : convertedRotation,
        'speed'    : convertedSpeed,
      });
      //results['stations][sid]に上記の情報を格納
      results['stations'][sid] = dic;
      //経度緯度時間の最大値と最小値を更新
      if (convertedLat > results['maxLat']) results['maxLat'] = convertedLat;
      if (convertedLat < results['minLat']) results['minLat'] = convertedLat;
      if (convertedLng > results['maxLng']) results['maxLng'] = convertedLng;
      if (convertedLng < results['minLng']) results['minLng'] = convertedLng;
      if (unixTime > results['maxUnixTime']) results['maxUnixTime'] = unixTime;
      if (unixTime < results['minUnixTime']) results['minUnixTime'] = unixTime;
    });
    //結果を返す
    res.json(results);
  };
 //時刻に基づくCam情報の検索
  Cam.selectByDate(from, to, callback);
});
/*
      'maxLat'      :  -90.0,
      'minLat'      :   90.0,
      'maxLng'      : -180.0,
      'minLng'      :  180.0,
      'maxUnixTime' : 0,
      'minUnixTime' : Number.MAX_VALUE,
      'stations'    : {sid : 'station'         : sid:
                                                 sname:
                             'stype'           : cam.stype
                             'protocolVersion' : cam.protocolVersion
                             'steps'           : [
                                                  'date'     : cam.date,
                                                  'unixTime' : unixTime,
                                                  'lat'      : convertedLat,
                                                  'lng'      : convertedLng,
                                                  'rotation' : convertedRotation,
                                                  'speed'    : convertedSpeed,
                                                 ],
                                                 [
                                                   'date'     : cam.date,
                                                   'unixTime' : unixTime,
                                                   'lat'      : convertedLat,
                                                   'lng'      : convertedLng,
                                                   'rotation' : convertedRotation,
                                                   'speed'    : convertedSpeed,
                                                 ]
                                                 .
                                                 .
                                                 .
                       sid :  
                        .
                        .
                        .
                      }
*/

/* Routeデータの登録（MongoDBのREST APIでも可） */
// 過去のデータ
// curl -X POST -d "sid"=1 -d "stype"=1 -d "date"="2016-01-01T00:00:00.000Z" -d "slat"=347999580 -d "slng"=1357737990 -d "glat"=347999580 -d "glng"=1357737990 -d "stime"=50 -d "gtime"=100 'http://localhost:3000/api/route/create'
// 現在のデータ (dateがない場合は現在時刻を挿入する)
// curl -X POST -d "sid"=1 -d "stype"=1 -d "slat"=347999580 -d "slng"=1357737990 -d "glat"=347999580 -d "glng"=1357737990 -d "stime"=50 -d "gtime"=100 'http://localhost:3000/api/route/create'

router.post('/route/create', function(req, res, next) {
  //callback処理（stationにはrequestのidのステーションが入る）
  //リクエストで受けたidのステーションを作成（更新）し、Viewerの画面の更新を行う
  var callback = function(err, station) {
    //エラー処理
    if(err) {
      res.json({
        'success' : false,
      });
      return;
    }
    //stationがなかったら
    if (!station) {
      //sidがPOSTで得られた値、snameが何もなしで新しく作成
      station = new DB.Station({"sid":req.body.sid, "sname":""})
      //stationをDBに追加
      station.save(function(err){
        if (err) { console.log(err); }
      });
    }
    //var sdate = Date.now;
    //var gdate = Date.now;
    //sdate.setSeconds(sdate.getSeconds()+parseInt(req.body.stime));
    //gdate.setSeconds(gdate.getSeconds()+parseInt(req.body.gtime));
    //大体requestで受け取った値
    
    var rparams = {
      'station'         : station,
      'date'            : (req.body.date) ? req.body.date : Date.now(),
      'rid'             : parseInt(req.body.rid), //パスの順番
      'slat'            : parseInt(req.body.slat), //パスのスタート地点
      'slng'            : parseInt(req.body.slng),
      'glat'            : parseInt(req.body.glat), //パスのゴール地点
      'glng'            : parseInt(req.body.glng),
      'stime'           : parseInt(req.body.stime), //対象のパスに入る時間
      'gtime'           : parseInt(req.body.gtime), //対象のパスを出る時間
      'polyline'        : req.body.polyline,
    };
    
    //paramsでCamデータベースのオブジェクトを作成
    var route = new DB.Route(rparams);
    //camを以下の状態にしてDBにアップする
    rcnt++;
    route.save(function(err) {
      if(err) {
        //return res.json({'success': false});
        res.json({
          'success' : false,
        });
      } else {
        // 現在時刻に近いデータの場合は、/present 画面を更新する。
        var diffSeconds = (Date.now() - route.date.getTime()) / 1000;
        if (diffSeconds < ACCEPTABLE_DIFF_SECONDS && WWW.socket) {
          // ステーション名がない場合には、ステーション名をIDにする
          if (station.sname == null || station.sname.length == 0) {
            station.sname = "ID:" + String(station.sid);
            rparams['station'] = station
          }
          rparams['slat']      /= Math.pow(10, 6); //10^6で割る
          rparams['slng']      /= Math.pow(10, 6);
          rparams['glat']      /= Math.pow(10, 6);
          rparams['glng']      /= Math.pow(10, 6);
/*以下複数ユーザへのブロードキャスト設定*/
          //WWW.socket.emit('update', params); これがデフォルト
          WWW.socket.broadcast.emit('update2', rparams);
          WWW.socket.emit('update2', rparams);
/*以上*/
        }

        res.json({
          'success' : true
        });
      }
    });
    
  };
　//requestのidのstationを見つける
  DB.Station.findOne({"sid" : req.body.sid}, callback);
});


router.get('/allroute/fetch', function(req, res, next) {
  
  var callback = function(err, routes) {
    
    if(err) {
      console.log(err);
    }
    //結果を返す
    console.log(rcnt);
    res.json(routes);
  };
 //時刻に基づくRoute情報の検索
  Cam.selectrAll(0,rcnt, callback);
});

router.get('/route/fetch', function(req, res, next) {
  
  var callback = function(err, routes) {
    
    if(err) {
      console.log(err);
    }
    //結果は以下の形式で返す
    results = {
      
    };
    //検索して出て来た各Camに対して以下の処理を実行
    routes.forEach(function(route) {
      dic = {}
      var convertedsLat      = route.slat / Math.pow(10, 6);//10^6で割る
      var convertedsLng      = route.slng / Math.pow(10, 6);
      var convertedgLat      = route.glat / Math.pow(10, 6);//10^6で割る
      var convertedgLng      = route.glng / Math.pow(10, 6);
      var station = route.station;
      var sid     = station.sid;
　　　　//result['stations']（返す結果）の中にsidがあったら
      if(sid in results) {
        //result['stations'][sid]の中身をdicに代入
        dic = results[sid]
      } else {
        //result['stations']のなかにsidがなかったら
        //dicに以下を代入
        dic = {
          'station'         : station,
          'routes'       : [],
        }
        // ステーション名がない場合には、IDをステーション名にする
        if (station.sname == null || station.sname.length == 0) {
          station.sname = "ID:" + String(station.sid);
          dic['station'] = station
        }
      }
      //dic[steps]に以下を入れる
      dic['routes'].push({
        'rid'       : route.rid,
        'slat'      : convertedsLat,
        'slng'      : convertedsLng,
        'glat'      : convertedgLat,
        'glng'      : convertedgLng,
        'stime'     : route.stime,
        'gtime'     : route.gtime,
        'polyline'  : route.polyline,
      });
      //results['stations][sid]に上記の情報を格納
      results[sid] = dic;
      //経度緯度時間の最大値と最小値を更新
    });
    //結果を返す
    res.json(results);
  };
 //時刻に基づくRoute情報の検索
  Cam.selectrAll(0,rcnt, callback);
});
/* Routeデータの登録（MongoDBのREST APIでも可） */
// 過去のデータ
// curl -X POST -d "sid"=1 -d "stype"=1 -d "date"="2016-01-01T00:00:00.000Z" -d "slat"=347999580 -d "slng"=1357737990 -d "glat"=347999580 -d "glng"=1357737990 -d "stime"=50 -d "gtime"=100 'http://localhost:3000/api/route/create'
// 現在のデータ (dateがない場合は現在時刻を挿入する)
// curl -X POST -d "lat"=35022209 -d "lng"=135766820 -d "cflag"=1 'http://localhost:3000/api/BaseStation/create'

router.post('/BaseStation/create', function(req, res, next) {
  //callback処理（stationにはrequestのidのステーションが入る）
  //リクエストで受けたidのステーションを作成（更新）し、Viewerの画面の更新を行う
    //エラー処理
  //res.send({"send parameter is" : req.body.lat});
  BScnt++;
  var BSparams = {
    'BSid'            : parseInt(req.body.BSid),
    'date'           : (req.body.date) ? req.body.date : Date.now(),
    'lat'            : parseInt(req.body.lat), //パスのスタート地点
    'lng'            : parseInt(req.body.lng),
  };
  
  //paramsでCamデータベースのオブジェクトを作成
  var BSdata = new DB.BSData(BSparams);
  //camを以下の状態にしてDBにアップする
  
  BSdata.save(function(err) {
    
    if(err) {
      //return res.json({'success': false});
      res.json({
        'success' : false,
      });
    } else {
      // 現在時刻に近いデータの場合は、/present 画面を更新する。
      var diffSeconds = (Date.now() - BSdata.date.getTime()) / 1000;
      if (diffSeconds < ACCEPTABLE_DIFF_SECONDS && WWW.socket) {
        // ステーション名がない場合には、ステーション名をIDにする
        BSparams['lat']      /= Math.pow(10, 6); //10^6で割る
        BSparams['lng']      /= Math.pow(10, 6);
/*以下複数ユーザへのブロードキャスト設定*/
        //WWW.socket.emit('update', params); これがデフォルト
        WWW.socket.broadcast.emit('update3', BSparams);
        WWW.socket.emit('update3', BSparams);
/*以上*/
      }

      res.json({
        'success' : true
      });
    } 
  });  

});

router.get('/BaseStation/fetch', function(req, res, next) {
  
  var callback = function(err, BSdata2) {
    
    if(err) {
      console.log(err);
    }
    //結果を返す
    console.log(BScnt);
    res.json(BSdata2);
  };
 //時刻に基づくRoute情報の検索
  Cam.selectcAll(0,BScnt, callback);
});

router.post('/cell/create', function(req, res, next) {
  //callback処理（stationにはrequestのidのステーションが入る）
  //リクエストで受けたidのステーションを作成（更新）し、Viewerの画面の更新を行う
    //エラー処理
  //res.send({"send parameter is" : req.body.lat});
  var BSDparams = {
    'BSid'            : parseInt(req.body.BSid),
    'date'           : (req.body.date) ? req.body.date : Date.now(),
    'radius'       : parseInt(req.body.radius),
    'lat'            : parseInt(req.body.lat), 
    'lng'            : parseInt(req.body.lng),
  };
  
  //paramsでCamデータベースのオブジェクトを作成
  var cells = new DB.Cell(BSDparams);
  //camを以下の状態にしてDBにアップする
  bcnt++;
  cells.save(function(err) {
    
    if(err) {
      //return res.json({'success': false});
      res.json({
        'success' : false,
      });
    } else {
      // 現在時刻に近いデータの場合は、/present 画面を更新する。
      var diffSeconds = (Date.now() - cells.date.getTime()) / 1000;
      if (diffSeconds < ACCEPTABLE_DIFF_SECONDS && WWW.socket) {
        // ステーション名がない場合には、ステーション名をIDにする
        BSDparams['lat']      /= Math.pow(10, 6); //10^6で割る
        BSDparams['lng']      /= Math.pow(10, 6);
/*以下複数ユーザへのブロードキャスト設定*/
        //WWW.socket.emit('update', params); これがデフォルト
        WWW.socket.broadcast.emit('update4', BSDparams);
        WWW.socket.emit('update4', BSDparams);
/*以上*/
      }

      res.json({
        'success' : true
      });
    } 
  });  

});

router.get('/cell/fetch', function(req, res, next) {
  
  var callback = function(err, cells) {
    
    if(err) {
      console.log(err);
    }
    //結果を返す
    console.log(bcnt);
    res.json(cells);
  };
 //時刻に基づくRoute情報の検索
  Cam.selectbAll(0,bcnt, callback);
});

module.exports = router;
