var map;
var data;
var stationDic;
var timer;
var time;
var diff = 1;
var indexes = {};

//ページ読み込み完了時に実行する関数
$(function(){
   //日付指定ピッカーの作成（past.ectのみ）
   //参考-> https://www.daterangepicker.com/
  $('input[name="daterange"]').daterangepicker({
    'timePicker': true, //日付に加えて時間を選択する選択ボックスを追加する
    'timePickerSeconds': true, //timePickerに秒を表示する
    'timePickerIncrement': 1, //時間の分の選択リストの増加
    'timePicker24Hour': true, //AM / PMの選択を削除して、12時間ではなく24時間を使用する
    //ボタンとラベルにローカライズされた文字列を提供し、日付形式をカスタマイズし、カレンダーの週の最初の曜日を変更できます。localeこれらのオプションをカスタマイズする方法については、構成ジェネレーターをチェックしてください。
    'locale': {
        //選択範囲の日付のフォーマット
        'format': 'YYYY/MM/DD HH:mm:ss'
    },
    'startDate': '2016-01-01', //(日付または文字列）最初に選択された日付範囲の開始日。文字列を指定する場合、locale設定で設定されている日付形式文字列と一致する必要があります。
    'endDate': '2016-03-31'   //（日付または文字列）最初に選択された日付範囲の終了日。
  }, function(start, end, label) {
    //Cam情報の取得
    //toISOString->時刻のISO形式に変える
    //05 October 2011 14:48 UTC-> 2011-10-05T14:48:00.000Z
    fetchCams(start.toISOString(), end.toISOString());
  });
});

//初期のマップの作成
function initMap() {
    // マップオプションの設定
    var mapOptions = {
      center: new google.maps.LatLng(34.801435, 135.769471),//中心座標の設定
      zoom: 14,
      mapTypeId: google.maps.MapTypeId.ROAD//マップタイプの指定
    };
    //地図の作成
    map = new google.maps.Map(document.getElementById('map'), mapOptions);
    // 縦幅を横幅に合わせる
    $('#map').css("height", "500px");
}

//選択された時間内のCam情報の取得
function fetchCams(startStr, endStr) {
  // console.log('fetch: from:' + startStr + ', to:' + endStr);
  // /api/cam/fetch に startStrとendStrと_dataのパラメータを加えたもののjsonを入手する（cam情報を手に入れる)(/route/api.js)
  $.getJSON("/api/cam/fetch?from=" + startStr + "&to=" + endStr, function(_data) { //dataにはcam情報が入る
    data = _data;
    stationDic = data['stations'];
/*
    'stations'    : {sid : 'station'         :    sid:
                                                  sname:
                           'stype'           : cam.stype,
                           'protocolVersion' : cam.protocolVersion,
                           'steps'           : [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               .
                                               .
                                               .
                     sid :  
                      .
                      .
                      .
                    }
*/
    //StationDicの中身がなかったら
    if (Object.keys(stationDic).length == 0) {
      alert('指定期間にはデータがありませんでした。');
      return;
    }

    var MARGIN = 0.001;
    // 北西端の座標を設定
    var sw = new google.maps.LatLng(data['maxLat'] + MARGIN, data['minLng'] - MARGIN);
    // 東南端の座標を設定
    var ne = new google.maps.LatLng(data['minLat'] - MARGIN, data['maxLng'] + MARGIN);
    // 範囲を設定
    var bounds = new google.maps.LatLngBounds(sw, ne);
    // マーカーが全て収まるように地図の中心とズームを調整して表示
    map.fitBounds(bounds);
    //cam情報に沿ってマーカーと経路オブジェクとを作成してstationDicに追加する
    initUI();
    //初期状態にリセットする
    initState();
  });
}

//cam情報に沿ってマーカーと経路オブジェクとを作成してstationDicに追加する
function initUI() {
  //#stationsの中身がなかったら
  $("#stations").empty();
  //stationDicのidの分回す
  for(stationId in stationDic){
    //色をランダムに決める
    var color = getRandomColor();
    var name = stationDic[stationId]['name'];
    var steps = stationDic[stationId]['steps'];
    //#stationsにステーションのチェックボックスを加える
    $("#stations").append('<p class="col-xs-3 col-md-3"><label><input type="checkbox" checked="checked" class="station-check" id="station-' + stationId + '"><span style="margin-left:10px;background-color:' + color + ';">　　</span> ' + name + '</label></p>');

    // パスの設定
    var lineCoordinates = [];
    //stepsの中のそれぞれの緯度と経度に対してオブジェクトを作ってlineCordinatesに追加する
    steps.forEach(function(step) {
      lineCoordinates.push(new google.maps.LatLng(step.lat, step.lng));
    });

    // パスの太さや色等の設定
   //経路のオブジェクトを作る
    var line = new google.maps.Polyline({
      path: lineCoordinates,
      strokeColor: color,
      strokeOpacity: 0.8,
      map: map
    });
    //マーカーの作成
    var marker = new google.maps.Marker({
      position: new google.maps.LatLng(0, 0),
      icon: {
        strokeColor: color,
        path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,//矢印の形
        scale: 3
      },
      map: map
    });
    //stationDicの'sid'に'line'と'marker'を追加
    stationDic[stationId]['line'] = line;
    stationDic[stationId]['marker'] = marker;
  }
}
/*
    stationDic    : {sid : 'station'         :    sid:
                                                  sname:
                           'stype'           : cam.stype,
                           'protocolVersion' : cam.protocolVersion,
                           'steps'           : [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               .
                                               .
                                               .
                           'line'            :   (lineobject)
                           'marker'          :   (markerobject) 
                     sid :  
                      .
                      .
                      .
                    }
*/

//初期状態にする(リセット)
function initState() {
  time = data['minUnixTime'];
  indexes = {};
  //すべてのidのマーカーを
  for(stationId in stationDic){
    var marker = stationDic[stationId]['marker'];
    //マーカーのオブジェクトの'position'を変更する
    marker.set('position', new google.maps.LatLng(0, 0));
    //マーカーをすべてマップから消す
    marker.setMap(null);
  }
  //#playと#clearを初期状態にする
  $("#play").prop("disabled", false);
  $("#clear").prop("disabled", true);
  updateClock();
  //すべてのマーカーと経路を消す
  removeAllSymbols();
}

//#station+idにチェックがついてるか(true,false)
function isChecked(stationId) {
  return $("#station-" + stationId).is(':checked');
}
//すべてのマーカーと経路を消す
function removeAllSymbols() {
  //stationDicの中身がなければ戻る
  if (stationDic == null) return;
  //あれば
  //すべてのマーカーと経路を消す
  for(stationId in stationDic){
    stationDic[stationId]['line'].setMap(null);
    stationDic[stationId]['marker'].setMap(null);
  }
}

//チェックされているidのマーカーと経路表示
function setMapForSymbol() {
  //すべてのidを確認する
  for(stationId in stationDic){
    var checked = isChecked(stationId);
    //idにチェックがついてたら
    if (checked) {
      //そのidの経路とマーカーを表示する
      stationDic[stationId]['line'].setMap(map);
      stationDic[stationId]['marker'].setMap(map);
    } else {
      //ついてなかったらその経路とマーカーを削除してmarkerの緯度経度を初期状態(0,0)にする
      stationDic[stationId]['line'].setMap(null);
      stationDic[stationId]['marker'].setMap(null);
      stationDic[stationId]['marker'].set('position', new google.maps.LatLng(0, 0));
    }
  }
}

//#stationsがクリックされたら
$('#stations').on("click", "input", function(){
  //チェックされているidのマーカーと経路表示
  setMapForSymbol();
});

//#speedsがクリックされたら(past.ect)
$('#speeds').on("click", "input", function(){
  //'speed'のチェックした値をdiffに入れる
  diff = parseInt($("input[name='speed']:checked").val());
});

//playがクリックされたら(past.ect)
$("#play").on("click", function(){
  //指定したCSSクラスがなかったら追加し、あったら削除する
  $(this).toggleClass("playing");
  $(this).toggleClass("btn-info");
  //#playの中の要素を消す
  $(this).empty();
　//#playにplayingというクラスがあった場合（再生中）
  if ($(this).hasClass("playing")) {
    //#playにコンテンツ追加(Pause)
    $(this).append('<span class="glyphicon glyphicon-pause"></span> Pause');
    //再生する
    play();
    //#clearのdistabledの値をtrueにする
    $("#clear").prop("disabled", true);
  //なかった場合
  } else {
    //#playにコンテンツ追加 (Play)
    $(this).append('<span class="glyphicon glyphicon-play"></span> Play');
    //一時停止する
    pause();
    //#clearのdisabledの値をfalseにする
    $("#clear").prop("disabled", false);
  }
});

//#clearがクリックされたら
$("#clear").on("click", function(){
  //音を一時停止する
  pause();
  //リセットする
  initState();
});

//時刻の更新
function updateClock() {
  var d = new Date((time + 60 * 60 * 9) * 1000);
  var dateStr = d.toISOString();
  dateStr = dateStr.replace("T", " ").replace(".000Z", "");
  $("#clock").text(dateStr);
}

//一時停止
function pause() {
  clearInterval(timer);
  //#clearのdisabledの値をfalseにする
  $("#clear").prop("disabled", false);
}


function displayStep(stationId, step) {
  //指定されたsidの指定されたステップのmarkerの緯度経度、アイコンの向きを再設定
  var marker = stationDic[stationId]['marker'];
  marker.set('position', new google.maps.LatLng(step.lat, step.lng));
  //アイコンの向きをiconの'rotation'に代入
  marker['icon']['rotation'] = step.orientation;
  //icon情報更新
  marker.set('icon', marker['icon']);
}

//指定されたsidの一番後ろのステップのmarkerの緯度経度、アイコンの向きを再設定
function displayLastStep(stationId) {
  var steps = stationDic[stationId]['steps'];
  var step = steps[steps.length - 1];
  //指定されたsidのmarkerの緯度経度、アイコンの向きを再設定
  displayStep(stationId, step);
}

//すべてのidの一番後ろのステップのmarkerの緯度経度、アイコンの向きを再設定
function displayAllLastStep() {
  for(stationId in stationDic){
    displayLastStep(stationId);
  }
}

function play() {
  //チェックされているidのマーカーと経路表示
  setMapForSymbol();
  //一定の遅延間隔を持って繰り返し実行
  timer = setInterval(function() {
    // console.log("time:" + time);
    //時間のアップデート
    updateClock();
    //すべてのidに対して以下を実行
    for(stationId in stationDic){

      var steps = stationDic[stationId]['steps'];

      var lastIndex = 0;
      //indexesの中にsidがあったら
      if (stationId in indexes) {
        //lastindexに代入
        lastIndex = indexes[stationId];
      }
      //もしlastindexがstepの長さより大きければ
      if(lastIndex >= steps.length) {
        //飛ばす
        continue;
      }
      //stepにstepsのlastindex番目を入れる
      var step = steps[lastIndex];
      //miUnixtime(初期)-speedで選択されてた値がステップのunixtimeより小さく、かつステップのUnixtimeがminUnixTimeより小さい場合
      //同一区間内に複数データがある場合
      if(time - diff < step.unixTime && step.unixTime <= time) {
        // console.log(stationId + " " + time + " " + step.lat + " " + step.lng + " " + step.orientation);
        //そのStationidにチェックがついてたとき
        if(isChecked(stationId)) {
          //そのsidとstepのmarkerの緯度経度、アイコンの向きを再設定
          displayStep(stationId, step);
        }

        // 同一区間内に複数データがある場合には飛ばす
        while(time - diff < step.unixTime && step.unixTime <= time) {
          //lastindexに１足す
          lastIndex++;
          // 最後のステップを表示して描画を終了する
          //ステップの最後の時
          if(lastIndex >= steps.length) {
            displayLastStep(stationId);
            // 最後のステップを表示して描画を終了する
            break;
          }
          //stepにlastindex番目のstepを入れる
          step = steps[lastIndex];
          //indexesのsid番目にlastIndexを代入
          indexes[stationId] = lastIndex;
        }
      }
    }

    time += diff;
    // 再生終了時
    if (time > data['maxUnixTime']) {
      displayAllLastStep();
      pause();
    }
  }, 1000);
}

function getRandomColor() {
  var letters = '0123456789ABCDEF'.split('');
  var color = '#';
  for (var i = 0; i < 6; i++ ) {
      color += letters[Math.floor(Math.random() * letters.length)];
  }
  return color;
}

//地図描画の実行
google.maps.event.addDomListener(window, 'load', initMap);


