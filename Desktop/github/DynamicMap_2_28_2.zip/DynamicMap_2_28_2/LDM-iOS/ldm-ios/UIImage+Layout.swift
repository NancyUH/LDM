//
//  UIImage+Layout.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/27.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import UIKit

extension UIImage {
    func width() -> CGFloat {
        return self.size.width
    }
    
    func height() -> CGFloat {
        return self.size.height
    }
}
