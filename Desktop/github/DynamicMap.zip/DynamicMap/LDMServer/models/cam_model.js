var DB = require('./db');

//SelectAllモジュールの作成、中に関数を入れる
exports.selectAll = function (skip, limit, callback) {
  //引数から要素を探すメソッド？
  DB.Cam.find({}, {}, {sort:{timestamp: -1}, skip: skip, limit: limit}, callback);
};

//selectByIDモジュールの作成
exports.selectById = function (id, callback) {
  //ID値に基づいた要素の検索
  DB.Cam.findById(new DB.ObjectId(id), callback);
};

//selsctByDateモジュールの作成
exports.selectByDate = function (from, to, callback) {
  //日付に基づいた要素の検索
  DB.Cam.find({"date": {"$gte": from, "$lte": to}}, {}, {sort:{date: 1}}, callback).populate('station');
};
