var express = require('express');

var router = express.Router();

/* GET home page. */
/*
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
*/
router.get('/', function(req, res, next) {
  // /で終わってる場合は/presentを読み込む
  res.redirect('/present');
});

// /presentページの作成
router.get('/present', function(req, res, next) {
  //?requestのリクエスト部分の読み込み
  res.render('present', {
    title       : 'LDM',
    isAlertMode : 'tid' in req.query,
    tid         : 'tid' in req.query && parseInt(req.query.tid),
  });
});

router.get('/past', function(req, res, next) {
  res.render('past', {
    title       : 'LDM',
    isAlertMode : 'tid' in req.query,
    tid         : 'tid' in req.query && parseInt(req.query.tid),
    start       : ('start' in req.query) ? req.query.start : "2016-01-01T00:00:00Z",
    end         : ('end' in req.query) ? req.query.end : "2016-01-01T00:00:00Z",
  });
});



module.exports = router;

