'use strict';

var ALERT_DISTANCE = 50; // meter
var DANGEROUS_DISTANCE = 10; // meter

var ALERT_STYLES = {
  "color"            : "yellow",
  "background-color" : "red",
  "font-weight"      : "bold",
  "padding"          : "0 8px",
};

var MAX_ZOOM_LEVEL = 18;

var TYPE_UNKNOWN       = 0;
var TYPE_PEDESTRIAN    = 1;
var TYPE_BICYCLE       = 2;
var TYPE_MOTORCYCLE    = 3;
var TYPE_MOTORBIKE     = 4;
var TYPE_AUTOMOBILE    = 5;
var TYPE_BUS           = 6;
var TYPE_SMALL_TRUCK   = 7;
var TYPE_LARGE_TRUCK   = 8;
var TYPE_TRAILER       = 9;
var TYPE_EMERGENCY_CAR = 10;
var TYPE_TRAM          = 11;
var TYPE_ROADSIDE_UNIT = 15;

var COLORS_BY_SPEED = ['gray', 'blue', 'cyan', 'green', 'yellow', 'orange', 'red'];
var EMPHASIS_FILL_COLOR_SELF     = 'red';
var EMPHASIS_STROKE_COLOR_SELF   = 'yellow';
var EMPHASIS_FILL_COLOR_IGNORE   = 'lightgray';
var EMPHASIS_STROKE_COLOR_IGNORE = 'yellow';

//svgPath(マーカーの形状)のタイプ別一覧
var svgPaths = {
  '0'  : "M25,0 L50,50 L0,50 L25,0 Z M17.8735352,21.4521484 L20.0268555,21.4521484 L20.0268555,34.4599609 C20.0268555,36.0029374 20.0561521,36.9648418 20.1147461,37.3457031 C20.2221685,38.1953167 20.4711895,38.9057589 20.8618164,39.4770508 C21.2524434,40.0483427 21.8530233,40.5268535 22.6635742,40.9125977 C23.4741251,41.2983418 24.2895467,41.4912109 25.1098633,41.4912109 C25.8227575,41.4912109 26.5063444,41.3398453 27.1606445,41.0371094 C27.8149447,40.7343735 28.3618142,40.3144558 28.8012695,39.7773438 C29.2407249,39.2402317 29.5629873,38.5908241 29.7680664,37.8291016 C29.9145515,37.2822238 29.987793,36.1591882 29.987793,34.4599609 L29.987793,21.4521484 L32.1411133,21.4521484 L32.1411133,34.4599609 C32.1411133,36.3837987 31.9531269,37.9389589 31.5771484,39.1254883 C31.20117,40.3120177 30.4492244,41.3447222 29.3212891,42.2236328 C28.1933537,43.1025435 26.8286213,43.5419922 25.2270508,43.5419922 C23.4887608,43.5419922 21.9995179,43.1269573 20.7592773,42.296875 C19.5190368,41.4667927 18.6889669,40.3681709 18.269043,39.0009766 C18.0053698,38.1611286 17.8735352,36.6474719 17.8735352,34.4599609 L17.8735352,21.4521484 Z",
  '1'  : "M25,0 L50,50 L0,50 L25,0 Z M18.7304688,21.4521484 L23.0224609,21.4521484 C25.4834107,21.4521484 27.1435504,21.5595692 28.0029297,21.7744141 C29.2334046,22.07715 30.2392539,22.6997023 31.0205078,23.6420898 C31.8017617,24.5844774 32.1923828,25.7685476 32.1923828,27.1943359 C32.1923828,28.62989 31.8115272,29.8139602 31.0498047,30.746582 C30.2880821,31.6792039 29.2382879,32.306639 27.9003906,32.6289062 C26.9238232,32.8632824 25.0976696,32.9804688 22.421875,32.9804688 L20.8837891,32.9804688 L20.8837891,43 L18.7304688,43 L18.7304688,21.4521484 Z M20.8837891,23.546875 L20.8837891,30.8710938 L24.53125,30.9150391 C26.0058667,30.9150391 27.0849575,30.7807631 27.7685547,30.512207 C28.4521519,30.243651 28.9892559,29.809085 29.3798828,29.2084961 C29.7705098,28.6079072 29.9658203,27.9365271 29.9658203,27.1943359 C29.9658203,26.4716761 29.7705098,25.8100616 29.3798828,25.2094727 C28.9892559,24.6088837 28.4741243,24.1816419 27.8344727,23.9277344 C27.194821,23.6738269 26.1474682,23.546875 24.6923828,23.546875 L20.8837891,23.546875 Z",
  '2'  : "M25,0 L50,50 L0,50 L25,0 Z M35.4956055,25.4511719 L33.7963867,26.7548828 C32.858882,25.5341736 31.733405,24.6088899 30.4199219,23.9790039 C29.1064387,23.3491179 27.6635821,23.0341797 26.0913086,23.0341797 C24.37255,23.0341797 22.780769,23.4467732 21.315918,24.2719727 C19.8510669,25.0971721 18.7158243,26.2055594 17.9101562,27.597168 C17.1044882,28.9887765 16.7016602,30.5537022 16.7016602,32.2919922 C16.7016602,34.9189584 17.6025301,37.1113193 19.4042969,38.8691406 C21.2060637,40.6269619 23.4789902,41.5058594 26.2231445,41.5058594 C29.2407377,41.5058594 31.7651266,40.3242306 33.7963867,37.9609375 L35.4956055,39.25 C34.4213813,40.6171943 33.0810627,41.6743127 31.4746094,42.4213867 C29.868156,43.1684608 28.0737404,43.5419922 26.0913086,43.5419922 C22.3217585,43.5419922 19.3481554,42.2871219 17.1704102,39.7773438 C15.3442292,37.6581925 14.4311523,35.0996244 14.4311523,32.1015625 C14.4311523,28.9472499 15.5370983,26.2934678 17.7490234,24.1401367 C19.9609486,21.9868056 22.7319169,20.9101562 26.0620117,20.9101562 C28.0737405,20.9101562 29.8901286,21.3081015 31.5112305,22.1040039 C33.1323323,22.8999063 34.460444,24.0156178 35.4956055,25.4511719 Z",
  '3'  : "M25,0 L50,50 L0,50 L25,0 Z M13.2006836,27.0625 L15.2368164,27.0625 L15.2368164,29.8164062 C15.9497106,28.8007762 16.6821251,28.0585961 17.434082,27.5898438 C18.4692435,26.9648406 19.5580998,26.6523438 20.7006836,26.6523438 C21.4721718,26.6523438 22.2045864,26.8037094 22.8979492,27.1064453 C23.5913121,27.4091812 24.1577126,27.8120092 24.597168,28.3149414 C25.0366233,28.8178736 25.4174789,29.5380812 25.7397461,30.4755859 C26.4233433,29.2255797 27.2778269,28.2758822 28.3032227,27.6264648 C29.3286184,26.9770475 30.432123,26.6523438 31.6137695,26.6523438 C32.7172907,26.6523438 33.691402,26.9306613 34.5361328,27.4873047 C35.3808636,28.0439481 36.0082987,28.8203075 36.418457,29.8164062 C36.8286153,30.812505 37.0336914,32.3066307 37.0336914,34.2988281 L37.0336914,43 L34.9389648,43 L34.9389648,34.2988281 C34.9389648,32.5898352 34.8168958,31.4155305 34.5727539,30.7758789 C34.3286121,30.1362273 33.9111358,29.6210957 33.3203125,29.2304688 C32.7294892,28.8398418 32.0239299,28.6445312 31.2036133,28.6445312 C30.2075146,28.6445312 29.2968791,28.9374971 28.4716797,29.5234375 C27.6464802,30.1093779 27.0434589,30.8906201 26.6625977,31.8671875 C26.2817364,32.8437549 26.0913086,34.4745979 26.0913086,36.7597656 L26.0913086,43 L24.0551758,43 L24.0551758,34.8408203 C24.0551758,32.9169826 23.9355481,31.6108433 23.6962891,30.9223633 C23.4570301,30.2338833 23.0395538,29.682131 22.4438477,29.2670898 C21.8481416,28.8520487 21.1401408,28.6445312 20.3198242,28.6445312 C19.3725539,28.6445312 18.4863323,28.9301729 17.6611328,29.5014648 C16.8359334,30.0727568 16.2255879,30.841792 15.8300781,31.8085938 C15.4345683,32.7753955 15.2368164,34.2548729 15.2368164,36.2470703 L15.2368164,43 L13.2006836,43 L13.2006836,27.0625 Z",
  '4'  : "M25,0 L50,50 L0,50 L25,0 Z M12.8564453,43 L15.9179688,21.4521484 L16.2695312,21.4521484 L25.0292969,39.1328125 L33.7011719,21.4521484 L34.0527344,21.4521484 L37.1435547,43 L35.0195312,43 L32.9101562,27.5898438 L25.2929688,43 L24.7509766,43 L17.03125,27.4726562 L14.9365234,43 L12.8564453,43 Z",
  '5'  : "M25,0 L50,50 L0,50 L25,0 Z M25.3295898,21.4521484 L35.378418,43 L33.0639648,43 L29.6801758,35.9101562 L20.3930664,35.9101562 L17.0239258,43 L14.621582,43 L24.8022461,21.4521484 L25.3295898,21.4521484 Z M25.065918,26.0224609 L21.3598633,33.8300781 L28.7280273,33.8300781 L25.065918,26.0224609 Z",
  '6'  : "M25,0 L50,50 L0,50 L25,0 Z M19.0673828,21.4521484 L23.3154297,21.4521484 C25.0244226,21.4521484 26.337886,21.6547831 27.2558594,22.0600586 C28.1738327,22.4653341 28.8989231,23.0878864 29.4311523,23.9277344 C29.9633816,24.7675823 30.2294922,25.7001902 30.2294922,26.7255859 C30.2294922,27.682622 29.9951195,28.5541953 29.5263672,29.340332 C29.0576148,30.1264688 28.3691452,30.7636694 27.4609375,31.2519531 C28.58399,31.6328144 29.4482392,32.0795873 30.0537109,32.5922852 C30.6591827,33.104983 31.1303694,33.725094 31.4672852,34.4526367 C31.8042009,35.1801794 31.9726562,35.9687458 31.9726562,36.8183594 C31.9726562,38.5468836 31.3403384,40.0092714 30.0756836,41.2055664 C28.8110288,42.4018615 27.1142685,43 24.9853516,43 L19.0673828,43 L19.0673828,21.4521484 Z M21.1767578,23.5615234 L21.1767578,30.4609375 L22.4072266,30.4609375 C23.9013747,30.4609375 24.9999965,30.3217787 25.703125,30.043457 C26.4062535,29.7651353 26.9628886,29.3256866 27.3730469,28.7250977 C27.7832052,28.1245087 27.9882812,27.4580115 27.9882812,26.7255859 C27.9882812,25.7392529 27.6440464,24.9653348 26.9555664,24.4038086 C26.2670864,23.8422823 25.170906,23.5615234 23.6669922,23.5615234 L21.1767578,23.5615234 Z M21.1767578,32.6289062 L21.1767578,40.890625 L23.8427734,40.890625 C25.4150469,40.890625 26.5673792,40.7368179 27.2998047,40.4291992 C28.0322302,40.1215805 28.6206032,39.6406283 29.0649414,38.9863281 C29.5092796,38.332028 29.7314453,37.6240272 29.7314453,36.8623047 C29.7314453,35.9052687 29.4189484,35.0703161 28.7939453,34.3574219 C28.1689422,33.6445277 27.3095758,33.1562513 26.2158203,32.8925781 C25.4833948,32.716796 24.2089935,32.6289062 22.3925781,32.6289062 L21.1767578,32.6289062 Z",
  '7'  : "M25,0 L50,50 L0,50 L25,0 Z M23.9892578,21.1445312 L26.0546875,21.1445312 L26.0546875,27.0625 L29.3066406,27.0625 L29.3066406,28.8203125 L26.0546875,28.8203125 L26.0546875,43 L23.9892578,43 L23.9892578,28.8203125 L21.1914062,28.8203125 L21.1914062,27.0625 L23.9892578,27.0625 L23.9892578,21.1445312 Z",
  '8'  : "M25,0 L50,50 L0,50 L25,0 Z M19.0966797,23.546875 L19.0966797,21.4521484 L30.9179688,21.4521484 L30.9179688,23.546875 L26.1132812,23.546875 L26.1132812,43 L23.9160156,43 L23.9160156,23.546875 L19.0966797,23.546875 Z",
  '9'  : "M25,0 L50,50 L0,50 L25,0 Z M19.6933594,21.4521484 L21.8613281,21.4521484 L21.8613281,40.9199219 L30.1376953,40.9199219 L30.1376953,43 L19.6933594,43 L19.6933594,21.4521484 Z",
  '10' : "M25,0 L50,50 L0,50 L25,0 Z M18.5947266,21.4521484 L30.9433594,21.4521484 L30.9433594,23.5761719 L20.7480469,23.5761719 L20.7480469,30.3144531 L30.8554688,30.3144531 L30.8554688,32.4238281 L20.7480469,32.4238281 L20.7480469,40.8759766 L30.8554688,40.8759766 L30.8554688,43 L18.5947266,43 L18.5947266,21.4521484 Z",
  '11' : "M25,0 L50,50 L0,50 L25,0 Z M16.3461914,21.4521484 L18.8657227,21.4521484 L24.0219727,29.8603516 L29.222168,21.4521484 L31.7124023,21.4521484 L25.2963867,31.8964844 L32.137207,43 L29.6176758,43 L24.0219727,33.9619141 L18.3969727,43 L15.8774414,43 L22.7475586,31.8964844 L16.3461914,21.4521484 Z",
  '15' : "M25,0 L50,50 L0,50 L25,0 Z M17.6352539,21.4521484 L21.9272461,21.4521484 C24.3198362,21.4521484 25.9409137,21.5498037 26.7905273,21.7451172 C28.0698306,22.0380874 29.1098593,22.6655225 29.9106445,23.6274414 C30.7114298,24.5893603 31.1118164,25.7734305 31.1118164,27.1796875 C31.1118164,28.3515684 30.8359403,29.3818315 30.2841797,30.2705078 C29.7324191,31.1591841 28.9438528,31.8305641 27.918457,32.284668 C26.8930613,32.7387718 25.4770598,32.9707031 23.6704102,32.9804688 L31.4194336,43 L28.753418,43 L21.019043,32.9804688 L19.7885742,32.9804688 L19.7885742,43 L17.6352539,43 L17.6352539,21.4521484 Z M19.7885742,23.5615234 L19.7885742,30.8857422 L23.4946289,30.9150391 C24.930183,30.9150391 25.9921841,30.7783217 26.6806641,30.5048828 C27.3691441,30.2314439 27.9062481,29.7944366 28.2919922,29.1938477 C28.6777363,28.5932587 28.8706055,27.9218787 28.8706055,27.1796875 C28.8706055,26.4570276 28.6752949,25.8002959 28.284668,25.2094727 C27.894041,24.6186494 27.3813508,24.1962903 26.746582,23.9423828 C26.1118132,23.6884753 25.0571363,23.5615234 23.5825195,23.5615234 L19.7885742,23.5615234 Z",
};

var svgEmphasisPath = "M25,0 L50,50 L0,50 L25,0 Z M25.5,12 L33,27 L18,27 L25.5,12 Z";

//audioのインスタンス
var alertSound = new Audio();
//プリロードを設定する
alertSound.preload = "auto";
//サウンドファイルのurl指定
alertSound.src = "/sounds/pon.mp3";
//読み込みを開始
alertSound.load();

//audioのインスタンス
var dangerousSound = new Audio();
//プリロードを設定する
dangerousSound.preload = "auto";
//サウンドファイルのurl指定
dangerousSound.src = "/sounds/ponpon.mp3";
//読み込みを開始
dangerousSound.load();

//初期のマップの作成
function initMap() {
    // マップオプションの設定
    var mapOptions = {
      center: new google.maps.LatLng(34.801435, 135.769471),//中心座標の設定
      zoom: 14,//ズームのレベル
      mapTypeId: google.maps.MapTypeId.ROAD//マップタイプの指定
    };
    //地図の作成
    map = new google.maps.Map(document.getElementById('map'), mapOptions);
    // 縦幅を横幅に合わせる
    $('#map').height($('#map').width());
}

// マップの境界の設定とその境界がうまく写るように設定
function fitBoundsForMap(map, minLat, maxLat, minLng, maxLng) {
  var MARGIN_RATIO = 0.0001;
  var marginLat = (maxLat - minLat) * MARGIN_RATIO;
  var marginLng = (maxLng - minLng) * MARGIN_RATIO;
  // 南西端の座標を設定
  var sw = new google.maps.LatLng(minLat - marginLat, minLng - marginLng);
  // 北東端の座標を設定
  var ne = new google.maps.LatLng(maxLat + marginLat, maxLng + marginLng);
  // 範囲を設定
  var bounds = new google.maps.LatLngBounds(sw, ne);
  // マーカーが全て収まるように地図の中心とズームを調整して表示
  map.fitBounds(bounds);
  if (map.getZoom() > MAX_ZOOM_LEVEL) {
    map.setZoom(MAX_ZOOM_LEVEL);
  }
}

//checkboxの作成と更新
// 凡例チェックボックス
// 警告モードの場合は全てチェックを外す(警告対象にする)
function addCheckboxElem(sname, stype, sid, checked, color) {
  var checkedHtml = (checked) ? ' checked="checked"' : '';
  var colorHtml   = (color) ? '<span style="margin-left:10px;background-color:' + color + ';">　　</span>' : '';
  var checkboxElem= '<p class="col-lg-3 col-md-3 col-sm-4 col-xs-6">' +
                      '<label class="col-lg-12 col-md-12 col-sm-12 col-xs-12">' +
                        '<input type="checkbox"' + checkedHtml + ' id="checkbox-' + sid + '" sid="' + sid + '" sname="' + sname + '" stype="' + stype + '">' +
                         colorHtml + ' ' + sname +
                      '</label>' +
                      '<span class="col-lg-7 col-md-7 col-sm-7 col-xs-12 station-info">' +
                        '(id:' + sid +', type:' + stype + ')' +
                      '</span>' +
                      '<span class="col-lg-5 col-md-5 col-sm-5 col-xs-12 distance" id="distance-' + sid + '"></span>' +
                    '</p>';


  $("#checkboxes").append(checkboxElem);
}

//target-stationの表示と更新
function addTargetStationElem(sname, stype, sid, color) {
  var colorHtml = "";
  if (color) {
    colorHtml = '<span style="margin-left:10px;background-color:' + color + ';">　　</span>';
  }
  var stationElem = '<p class="col-xs-3 col-md-3">' +
                      '<label>' +
                         colorHtml + ' ' + sname + '</br>(id:' + sid +', type:' + stype + ')' +
                      '</label>' +
                    '</p>';

  $("#target-station").append(stationElem);
}

//指定したIDのチェックボックスにチェックされているか
function isChecked(sid) {
  return $("#checkbox-" + sid).is(':checked');
}

//マーカーの作成（緯度と経度の指定なし）
function makeMarker(map, sid, stype) {
  return makeMarker(map, sid, stype, 0, 0);
}

//マーカーの作成（緯度と経度の指定あり）
function makeMarker(map, sid, stype, lat, lng) {
  var icon = {
    path         : svgPaths[stype], //マーカーの形状
    strokeColor  : 'white',
    strokeWeight : 1.5,
    fillColor    : COLORS_BY_SPEED[0],
    fillOpacity  : 0.8,
    scale        : 0.4,
    // △の真ん中を基準点にする場合
    anchor       : new google.maps.Point(26, 28),
    origin       : new google.maps.Point(26, 28),
    // △の先頭を基準点にする場合
    //anchor       : new google.maps.Point(26, 0),
    //origin       : new google.maps.Point(26, 0),
  };

//アラートモードの時のマーカーは固定
  if (isAlertMode) {
    icon['path']        = svgEmphasisPath;
    icon['fillColor']   = (sid == tid) ? EMPHASIS_FILL_COLOR_SELF : EMPHASIS_FILL_COLOR_IGNORE;
    icon['strokeColor'] = (sid == tid) ? EMPHASIS_STROKE_COLOR_SELF : EMPHASIS_STROKE_COLOR_IGNORE;
  }
    // 警告モードの際は色を固定(無効中)
  /*
  if (isAlertMode && (sid == tid)) {
  	marker['icon']['path']        = svgEmphasisPath;
    marker['icon']['fillColor']   = EMPHASIS_FILL_COLOR_SELF;
    marker['icon']['strokeColor'] = EMPHASIS_STROKE_COLOR_SELF;
  }
  */

  //マーカーの作成
  var marker = new google.maps.Marker({
    position : new google.maps.LatLng(lat, lng),
    icon     : icon,
    map      : map,
    sid      : sid,
  });

  return marker;
}

//経路を繋ぐ線の描画
function makeLine(map, steps, color) {
  // パスの設定
  var lineCoordinates = [];
  steps.forEach(function(step) {
    lineCoordinates.push(new google.maps.LatLng(step.lat, step.lng));
  });

  // パスの太さや色等の設定
  var line = new google.maps.Polyline({
    path          : lineCoordinates,
    strokeColor   : color,
    strokeOpacity : 0.8,
    map           : map
  });
  return line;
}

//警告範囲の表示時の円の作成
function makeAlertCircle(map) {
  return new google.maps.Circle({
    center: new google.maps.LatLng(0, 0),
    fillColor: '#ff0000',   // 塗りつぶし色
    fillOpacity: 0.1,       // 塗りつぶし透過度（0: 透明 ⇔ 1:不透明）
    map: map,               // 表示させる地図（google.maps.Map）
    radius: ALERT_DISTANCE, // 半径（ｍ）
    strokeColor: '#ff0000', // 外周色
    strokeOpacity: 0.3,     // 外周透過度（0: 透明 ⇔ 1:不透明）
    strokeWeight: 1         // 外周太さ（ピクセル）
  });
}

//マーカーの色設定
function selectColorByType(stype, kilometerPerHour) {
  switch (stype) {
    case TYPE_PEDESTRIAN:
      if(kilometerPerHour < 1)  return COLORS_BY_SPEED[3];
      if(kilometerPerHour < 3)  return COLORS_BY_SPEED[3];
      if(kilometerPerHour < 5)  return COLORS_BY_SPEED[5];
      if(kilometerPerHour < 100)  return COLORS_BY_SPEED[5];
      return COLORS_BY_SPEED[COLORS_BY_SPEED.length - 1];
      break;
    case TYPE_MOTORCYCLE:
    case TYPE_MOTORBIKE:
    case TYPE_AUTOMOBILE:
      if(kilometerPerHour < 1)   return COLORS_BY_SPEED[0];
      if(kilometerPerHour < 10)  return COLORS_BY_SPEED[1];
      if(kilometerPerHour < 40)  return COLORS_BY_SPEED[2];
      if(kilometerPerHour < 60)  return COLORS_BY_SPEED[4];
      if(kilometerPerHour < 80)  return COLORS_BY_SPEED[6];
      if(kilometerPerHour < 100) return COLORS_BY_SPEED[6];
      return COLORS_BY_SPEED[COLORS_BY_SPEED.length - 1];
      break;
    case TYPE_BUS:
    case TYPE_SMALL_TRUCK:
    case TYPE_LARGE_TRUCK:
    case TYPE_TRAILER:
    case TYPE_EMERGENCY_CAR:
    case TYPE_TRAM:
      if(kilometerPerHour < 1)   return COLORS_BY_SPEED[0];
      if(kilometerPerHour < 40)  return COLORS_BY_SPEED[1];
      if(kilometerPerHour < 60)  return COLORS_BY_SPEED[2];
      if(kilometerPerHour < 70)  return COLORS_BY_SPEED[4];
      if(kilometerPerHour < 80)  return COLORS_BY_SPEED[6];
      if(kilometerPerHour < 100) return COLORS_BY_SPEED[6];
      return COLORS_BY_SPEED[COLORS_BY_SPEED.length - 1];
      break;
    // タイプに応じた条件を記載する
    default:
      return COLORS_BY_SPEED[0];
      break;
  }
}

//マーカーアイコンの設定（警告時や通常時、タイプ）
function setIconForMarker(marker, stype, lat, lng, rotation, kilometerPerHour) {
  // 緯度経度
  marker.set('position', new google.maps.LatLng(lat, lng));
  // 角度
  marker['icon']['rotation'] = rotation;
  // カラーとパス
  var sid = marker.sid;
  // 警告モードかつ、強調表示対象
  //if (isAlertMode && (marker.sid == tid || isChecked(marker.sid))) {
  if (isAlertMode && (marker.sid == tid)) {
  	marker['icon']['path']        = svgEmphasisPath;
    marker['icon']['fillColor']   = EMPHASIS_FILL_COLOR_SELF;
    marker['icon']['strokeColor'] = EMPHASIS_STROKE_COLOR_SELF;
  	/*
    marker['icon']['path']        = svgEmphasisPath;
    marker['icon']['fillColor']   = (sid == tid) ? EMPHASIS_FILL_COLOR_SELF : EMPHASIS_FILL_COLOR_IGNORE;
    marker['icon']['strokeColor'] = (sid == tid) ? EMPHASIS_STROKE_COLOR_SELF : EMPHASIS_STROKE_COLOR_IGNORE;
    */
    /*
    var color = selectColorByType(stype, kilometerPerHour);
    marker['icon']['path']        = svgEmphasisPath;
    marker['icon']['fillColor']   = (sid == tid) ? EMPHASIS_FILL_COLOR_SELF : color;
    marker['icon']['strokeColor'] = (sid == tid) ? EMPHASIS_STROKE_COLOR_SELF : 'white';
    */
  } else {
    var color = selectColorByType(stype, kilometerPerHour);
    //marker['icon']['path']        = svgPaths[stype];
    marker['icon']['path']        = svgEmphasisPath;
    marker['icon']['fillColor']   = color;
    marker['icon']['strokeColor'] = (color == 'yellow') ? 'gray' : 'white';
  }
  marker.set('icon', marker['icon']);
}

//指定したidの指定したオブジェクトを地図に設置
function setMapForObject(stationDic, sid, key) {
  //指定したidのチェックボックスにチェックされているか
  //key -> 'marker'(present.jsで使う) 'line'(past.jsで使う)
  var checked = isChecked(sid);
  //チェックされていたら
  if (checked) {
    //指定した地図に設置
    stationDic[sid][key].setMap(map);
  } else {
    //何も設置しない
    stationDic[sid][key].setMap(null);
  }
}

//指定したidのマーカーを地図に設置
function setMapForMarker(stationDic, sid) {
  // 警告モードの際はマーカーを非表示にしない(強調表示か否かが変わるのみ)
  if (isAlertMode) return;
  setMapForObject(stationDic, sid, 'marker');
}

//ステーションのチェックしているすべてのマーカーを設置
function setMapForMarkers(stationDic) {
  for(sid in stationDic){
    setMapForMarker(stationDic, sid);
  }
}

//線を地図に描画
function setMapForLine(stationDic, sid) {
  setMapForObject(stationDic, sid, 'line');
}


function setMapForLines(stationDic) {
  for(sid in stationDic){
    setMapForLine(stationDic, sid);
  }
}

//マーカーの削除
function removeMarker(stationDic, sid) {
  stationDic[sid]['marker'].setMap(null);
}

//すべてのマーカーの削除
function removeAllMarkers(stationDic) {
  for(sid in stationDic){
    removeMarker(stationDic, sid);
  }
}

//線の削除
function removeLine(stationDic, sid) {
  stationDic[sid]['line'].setMap(null);
}

//すべての線の削除
function removeAllLines(stationDic) {
  for(sid in stationDic){
    removeLine(stationDic, sid);
  }
}

function handleAlert(sid, lat1, lng1, lat2, lng2, alertStations, dangerousStations) {
  // 距離を算出し、必要に応じてアラートを出す
  // アラートを出す必要がない場合は、リストから消す
  //距離を出す
  var distance = getDistance(lat1, lng1, lat2, lng2);
  //IDにチェックがついてなくて、警告距離より近かったときにTrue
  var isAlert  = (!isChecked(sid) && distance <= ALERT_DISTANCE);
　
  //距離を表示、近い場合はアラートを表示
  displayDistance(sid, distance, isAlert);

  if (isAlert && alertStations.indexOf(sid) < 0) {
    //alertStationにidを追加
    alertStations.push(sid);
    playAlertSound();
    //アラートが出す必要がないとき
  } else if (!isAlert && alertStations.indexOf(sid) >= 0) {
    alertStations.splice(alertStations.indexOf(sid), 1);
  }
　//危険距離より近かったときTrue
  var isDangerous  = (!isChecked(sid) && distance <= DANGEROUS_DISTANCE);
  if (isDangerous && dangerousStations.indexOf(sid) < 0) {
    //dengerousStationにidを追加
    dangerousStations.push(sid);
    playDangerousSound();
  } else if (!isDangerous && dangerousStations.indexOf(sid) >= 0) {
    dangerousStations.splice(dangerousStations.indexOf(sid), 1);
  }
}

//距離の算出
function getDistance(lat1, lng1, lat2, lng2) {
  var latLng1 = new google.maps.LatLng(lat1, lng1);
  var latLng2 = new google.maps.LatLng(lat2, lng2);
  //緯度同士の直線距離を求める
  return parseInt(google.maps.geometry.spherical.computeDistanceBetween(latLng1, latLng2));
}

//Stringにフォーマット
function formatDistance(distance) {
  return String(distance).replace( /(\d)(?=(\d\d\d)+(?!\d))/g, '$1,' ) + " m";
}

// 距離を表示し、近い場合にはアラートスタイルで表示する。
function displayDistance(sid, distance, isAlert) {
  //距離をstringにフォーマット
  var distanceStr = formatDistance(distance);
  //表示
  $('#distance-' + sid).text(distanceStr);
  if(isAlert) {
    $('#distance-' + sid).html(distanceStr).css(ALERT_STYLES);
  } else {
    $('#distance-' + sid).removeAttr("style");
  }
}

//アラートを表示
function displayAlert(alertStations) {
  var text = "警報範囲内のステーションID: " + alertStations.sort();
  $('#near-station-alert').text(text);
}

//警告音を再生
function playAlertSound() {
  // すでに再生中の場合は無視
  if(!alertSound.paused) return;
  alertSound.currentTime = 0;
  //再生
  alertSound.play();
}

//危険音を再生
function playDangerousSound() {
  // すでに再生中の場合は無視
  if(!dangerousSound.paused) return;
  dangerousSound.currentTime = 0;
  //再生
  dangerousSound.play();
}

//all-checkのチェックボックスが変化したら
$('#all-check').on("change", function() {
  //その通りにidのすべてのチェックボックスを変化させる
  $("[id^=checkbox-]").prop('checked', $(this).prop('checked')).trigger('change');
});


//テキストボックス上でキーボードが押されたら
$('#regex').keypress(function(e) {
  // Enterキーではない場合
  if (e.which != 13) {
    return true;
  }

  //idのチェックボックス
  var checkboxes = $("[id^=checkbox-]");
  // 全てチェックする
  checkboxes.prop('checked', true);
　
  //空白で分割する（idとtypeとnameで分かれる)
  var params = $(this).val().split(' ');
  //それぞれのパラメータに関して処理をする
  params.forEach(function(param) {
    // パラメータが異常値
    if (param.length == 0 || param.indexOf(':') < 0) {
      return;
    }
    //:で分けたときの前の方(id,type,name)をkey、後ろの方(それぞれの値)をvalに代入
    var key = param.split(':')[0];
    var val = param.split(':')[1];

    checkboxes.each(function(index) {
      // 現状チェックがついていて、正規表現にマッチする場合はチェック
      if (!$(this).is(':checked')) {
        return;
      }

      //値の方の正規表現オブジェクトを生成、reに代入
      var re = new RegExp(val);
      if (key == 'type') {
        //stype内にある属性があった場合チェックを入れる
        $(this).prop('checked', re.test($(this).attr('stype'))).trigger('change');
      }
      else if (key == 'name') {
        //sname内にある属性があった場合チェックを入れる
        $(this).prop('checked', re.test($(this).attr('sname'))).trigger('change');
      }
      else if (key == 'id') {
        //sid内にある属性があった場合チェックを入れる
        $(this).prop('checked', re.test($(this).attr('sid'))).trigger('change');
      }
    });
  });
  return false;
});
