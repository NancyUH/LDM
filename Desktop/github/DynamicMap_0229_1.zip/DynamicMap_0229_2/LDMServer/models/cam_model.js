var DB = require('./db');

//SelectAllモジュールの作成、中に関数を入れる
exports.selectAll = function (skip, limit, callback) {
  //引数から要素を探すメソッド？
  DB.Cam.find({}, {}, {sort:{timestamp: -1}, skip: skip, limit: limit}, callback);
  //第一引数->検索条件、第二引数->取得するフィールド名（１で表示、０で非表示）、sort{timestamp : -1}->timestampの降順で表示(昇順は1)、skip:skip->飛ばす件数、limit:limit->取得する件数
  //参考：https://qiita.com/saba1024/items/f2ad56f2a3ba7aaf8521
  //https://babiy3104.hateblo.jp/entry/2013/11/11/201927
};

//selectByIDモジュールの作成
exports.selectById = function (id, callback) {
  //ID値に基づいた要素の検索
  DB.Cam.findById(new DB.ObjectId(id), callback);
};

//selsctByDateモジュールの作成
exports.selectByDate = function (from, to, callback) {
  //日付に基づいた要素の検索
  DB.Cam.find({"date": {"$gte": from, "$lte": to}}, {}, {sort:{date: 1}}, callback).populate('station');
  //{$gte: from, $lite:to}->$gteの引数より大きいものかつ$liteの引数より小さいもの、populate->リレーション先のドキュメントも一緒に表示
  //参考:https://qiita.com/koyopro/items/8be2c6c3965feca42aa6
};

//selectBySidモジュールの作成
exports.selectBySid = function(sid, callback) {
  //sidに基づいた要素の検索
  DB.Route.find({"sid": sid}, {},{sort:{rid: 1}}, callback).populate('station');
};
exports.selectByStation = function(station, callback) {
  //sidに基づいた要素の検索
  DB.Route.find({"station": station}, {},{sort:{rid: 1}}, callback).populate('station');
};

//selectBySidモジュールの作成
exports.selectByBSid = function(BSid, callback) {
  //sidに基づいた要素の検索
  DB.TResv.find({"BSid": BSid}, {},{sort:{sid: 1}}, callback).populate('BSdata');
};

exports.selectByBSdata = function(BSdata, callback) {
  //sidに基づいた要素の検索
  DB.TResv.find({"BSdata": BSdata}, {},{sort:{sid: 1}}, callback).populate('BSdata');
};


exports.selectrAll = function (skip, limit, callback) {
  //引数から要素を探すメソッド？
  DB.Route.find({}, {}, {sort:{timestamp: -1}, skip: skip, limit: limit}, callback).populate('station');
  //第一引数->検索条件、第二引数->取得するフィールド名（１で表示、０で非表示）、sort{timestamp : -1}->timestampの降順で表示(昇順は1)、skip:skip->飛ばす件数、limit:limit->取得する件数
  //参考：https://qiita.com/saba1024/items/f2ad56f2a3ba7aaf8521
  //https://babiy3104.hateblo.jp/entry/2013/11/11/201927
};

exports.selectcAll = function (skip, limit, callback) {
  //引数から要素を探すメソッド？
  DB.BSData.find({}, {}, {sort:{timestamp: -1}, skip: skip, limit: limit}, callback);
  //第一引数->検索条件、第二引数->取得するフィールド名（１で表示、０で非表示）、sort{timestamp : -1}->timestampの降順で表示(昇順は1)、skip:skip->飛ばす件数、limit:limit->取得する件数
  //参考：https://qiita.com/saba1024/items/f2ad56f2a3ba7aaf8521
  //https://babiy3104.hateblo.jp/entry/2013/11/11/201927
};

exports.selectbAll = function (skip, limit, callback) {
  //引数から要素を探すメソッド？
  DB.Cell.find({}, {}, {sort:{timestamp: -1}, skip: skip, limit: limit}, callback).populate('BSdata');
  //第一引数->検索条件、第二引数->取得するフィールド名（１で表示、０で非表示）、sort{timestamp : -1}->timestampの降順で表示(昇順は1)、skip:skip->飛ばす件数、limit:limit->取得する件数
  //参考：https://qiita.com/saba1024/items/f2ad56f2a3ba7aaf8521
  //https://babiy3104.hateblo.jp/entry/2013/11/11/201927
};

