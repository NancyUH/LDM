//
//  SettingViewController.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/30.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireObjectMapper
import SwiftyUserDefaults

class SettingViewController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {

    @IBOutlet weak var hostLabel: UILabel!
    @IBOutlet weak var hostTextField: UITextField!
    @IBOutlet weak var portLabel: UILabel!
    @IBOutlet weak var portTextField: UITextField!
    @IBOutlet weak var snameLabel: UILabel!
    @IBOutlet weak var snameTextField: UITextField!
    @IBOutlet weak var sidLabel: UILabel!
    @IBOutlet weak var sidTextField: UITextField!
    @IBOutlet weak var stypeLabel: UILabel!
    @IBOutlet weak var stypePickerView: UIPickerView!
    @IBOutlet weak var saveButton: UIButton!
    
   //fileprivate let typeKeys: NSArray = ["不明（0）", "歩行者（1）", "自転車（2）", "原付き（3）", "自動二輪（4）", "自動車（5）", "バス（6）", "小型トラック（7）", "大型トラック（8）", "トレーラ（9）", "緊急車両（10）", "トラム（11）", "路側機（15）"]
    fileprivate let typeKeys: NSArray = ["歩行者（1）","自動車（5）"]
    //fileprivate let typeValues:[Int] = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 15]
    fileprivate let typeValues:[Int] = [1, 5]
    fileprivate var selectedRow: Int!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        stypePickerView.delegate = self
        stypePickerView.dataSource = self
        
        hostTextField.delegate = self;
        portTextField.delegate = self;
        snameTextField.delegate = self;
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        initView()
        initContent()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }

    func initView() {
        hostLabel.origin = CGPoint(x: kMargin, y: ViewManager.kStatusBarHeight + ViewManager.kNavigationBarHeight(self) + kMargin);
        hostTextField.frame = CGRect(x: kMargin * 2, y: hostLabel.bottom, width: ViewManager.kScreenWidth - kMargin * 3, height: hostTextField.height)
        
        portLabel.origin = CGPoint(x: hostLabel.left, y: hostTextField.bottom + kMargin);
        portTextField.frame = CGRect(x: hostTextField.left, y: portLabel.bottom, width: hostTextField.width, height: portTextField.height)
        
        snameLabel.origin = CGPoint(x: hostLabel.left, y: portTextField.bottom + kMargin);
        snameTextField.frame = CGRect(x: hostTextField.left, y: snameLabel.bottom, width: hostTextField.width, height: snameTextField.height)
        
        sidLabel.origin = CGPoint(x: hostLabel.left, y: snameTextField.bottom + kMargin);
        sidTextField.frame = CGRect(x: hostTextField.left, y: sidLabel.bottom, width: hostTextField.width, height: snameTextField.height)
        
        stypeLabel.origin = CGPoint(x: hostLabel.left, y: sidTextField.bottom + kMargin);
        stypePickerView.frame = CGRect(x: ViewManager.kScreenWidth * 0.1, y: stypeLabel.bottom, width: ViewManager.kScreenWidth * 0.8, height: 160)
        
        saveButton.frame = CGRect(x: kMargin, y: ViewManager.kScreenHeight - saveButton.height - kMargin, width: ViewManager.kScreenWidth - kMargin * 2, height: saveButton.height)
    }
    
    func initContent() {
        hostTextField.text = Defaults[.host]
        portTextField.text = Defaults[.port]
        snameTextField.text = Defaults[.sname]
        if let sid = Defaults[.sid] {
            sidTextField.text = String(sid)
        }
        if let index = typeValues.index(of: Defaults[.stype]) {
            selectedRow = index
            stypePickerView.selectRow(selectedRow, inComponent: 0, animated: false)
        }
    }
    
    // MARK: - PickerViewDelegate
    // 列数
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    // 行数
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return typeKeys.count
    }
    // 値
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return typeKeys[row] as? String
    }
    // 選択時
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        selectedRow = row
    }
    
    func updateUserDefault(_ sid: Int) {
        Defaults[.isInited] = true
        Defaults[.sid] = sid
        Defaults[.host] = hostTextField.text!
        Defaults[.port] = portTextField.text!
        Defaults[.sname] = snameTextField.text!
        Defaults[.stype] = typeValues[selectedRow]
    }
    
    @IBAction func pushedSaveButton(_ sender: Any) {
        var params = Dictionary<String, Any>()
        params["sname"] = snameTextField.text as Any
        if !sidTextField.text!.isEmpty {
            params["sid"] = Int(sidTextField.text!)!
        }
        Alamofire.request(kBaseUrl + "station/create", method: .post, parameters: params).responseObject { (response: DataResponse<StationCreateResponse>) in
            let stationCreateResponse = response.result.value
            if stationCreateResponse!.success {
                self.updateUserDefault(stationCreateResponse!.sid)
                _ = self.navigationController?.popViewController(animated: true)
                return
            }
            
            let alertController: UIAlertController = UIAlertController(title:"Error", message: nil, preferredStyle: .alert)
            let defaultAction = UIAlertAction(title: "OK", style: .default, handler: nil)
            alertController.addAction(defaultAction)
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    // MARK: - TextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        switch textField {
        case hostTextField:
            portTextField.becomeFirstResponder()
            break
//        case portTextField:
//            snameTextField.becomeFirstResponder()
//            break
        case snameTextField:
            sidTextField.becomeFirstResponder()
            break
        default:
            break
        }
        return true
    }
    
}
