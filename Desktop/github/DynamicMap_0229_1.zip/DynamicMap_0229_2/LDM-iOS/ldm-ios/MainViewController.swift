//
//  MainViewController.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/27.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import UIKit
import Alamofire
import AlamofireObjectMapper
import CoreLocation
import SwiftyUserDefaults

class MainViewController: UIViewController, CLLocationManagerDelegate {
    
    @IBOutlet weak var infoLabel: UILabel!
    @IBOutlet weak var startButton: UIButton!
    @IBOutlet weak var webButton: UIButton!
    @IBOutlet weak var timeSegmentedControl: UISegmentedControl!
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var datePicker: UIDatePicker!
    
    var locationManager: CLLocationManager!
    var originalButtonColor: UIColor!
    var timer: Timer?
    var rotation = 0.0
    var rotationAccuracy = 0.0
    var isStarting = false
    var isUpdating = false
    var terminatingDate: Date!
    var timerE:Timer!
    var camC : Cam!
    var camFlag = false
    var uploadFlag = false
    
    enum TerminatePattern: Int {
        case `default`    // 一定期間後
        case selection  // ユーザー指定
        case non         // 自動停止しない
    }
    
    struct TimeLabel {
        static let p0 = "90分後に自動停止します"
        static let p1 = "%02d:%02dに自動停止します"
        static let p2 = "手動でのみ停止します"
        static func toString(_ pattern: TerminatePattern, date: Date) -> String {
            switch pattern {
            case TerminatePattern.default:
                return TimeLabel.p2
                //return TimeLabel.p0
            case TerminatePattern.selection:
                //let calendar = Calendar.current
                //let comp = (calendar as NSCalendar).components([.hour, .minute], from: date)
                //let hour = comp.hour
                //let minute = comp.minute
                //return String(format: p1, hour!, minute!)
                return TimeLabel.p2
            case TerminatePattern.non:
                return TimeLabel.p2
            }
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if !Defaults[.isInited] {
            initUserDefaults()
            let settingViewController = SettingViewController()
            self.navigationController?.pushViewController(settingViewController, animated: true)
        }
        
        initLocationManager()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        initView()
    }
    
    func initView() {
        infoLabel.frame = CGRect(x: kMargin * 2, y: ViewManager.kStatusBarHeight + ViewManager.kNavigationBarHeight(self) + kMargin , width: ViewManager.kScreenWidth - kMargin * 4, height: 90)
        
        timeSegmentedControl.frame = CGRect(x: kMargin, y: infoLabel.bottom + kMargin, width: ViewManager.kScreenWidth - kMargin * 2, height: timeSegmentedControl.height)
        timeLabel.frame = CGRect(x: kMargin, y: timeSegmentedControl.bottom + kMargin, width: ViewManager.kScreenWidth - kMargin * 2, height: timeLabel.height)
        timeLabel.text = TimeLabel.p0
        
        datePicker.datePickerMode = UIDatePickerMode.time
        datePicker.frame = CGRect(x: 0, y: timeLabel.bottom + kMargin, width: ViewManager.kScreenWidth, height: datePicker.height)
        
        webButton.frame = CGRect(x: kMargin, y: ViewManager.kScreenHeight - webButton.height - kMargin, width: ViewManager.kScreenWidth - kMargin * 2, height: webButton.height)
        
        startButton.frame = CGRect(x: kMargin, y: webButton.top - startButton.height - kMargin * 2, width: ViewManager.kScreenWidth - kMargin * 2, height: startButton.height)
        originalButtonColor = startButton.backgroundColor
        
        let settingMenuButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonSystemItem.edit, target: self, action: #selector(MainViewController.pushedSettingMenuButton(_:)))
        self.navigationItem.setRightBarButtonItems([settingMenuButton], animated: true)
    }
    
    func initLocationManager() {
        locationManager = CLLocationManager()
        locationManager.allowsBackgroundLocationUpdates = true
        // 位置情報取得間隔(m)
        locationManager.distanceFilter = 0
        // 位置情報取得精度
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
    }
    
    func pushedSettingMenuButton(_ sender: Any) {
        let settingViewController = SettingViewController()
        self.navigationController?.pushViewController(settingViewController, animated: true)
    }
    
    @IBAction func changedSegmentedControl(_ sender: Any) {
        let index = timeSegmentedControl.selectedSegmentIndex
        datePicker.isHidden = index != 1;
        timeLabel.text = TimeLabel.toString(TerminatePattern(rawValue: index)!, date: datePicker.date)
    }
    
    @IBAction func changedDatePicker(_ sender: Any) {
        timeLabel.text = TimeLabel.toString(TerminatePattern.selection, date: datePicker.date)
        terminatingDate = datePicker.date
    }
    
    @IBAction func pushedStartButton(_ sender: Any) {
        isStarting = !isStarting
        if isStarting {
            // GPS/Headingが止まっている場合は開始
            if !isUpdating {
                startUpdating()
            }
            startTimerIfNeeded()
        } else {
            stopTimerIfNeeded()
        }
        setStartButtonState()
        /*--以下追加--*/

        if timerE == nil {
            timerE = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(self.timerEvent), userInfo: nil, repeats: true)
        }else{
            timerE.invalidate()
            timerE = nil
            camC = nil
        }

    }
    
    func timerEvent(){
        if camC != nil{
            if camFlag == true{
                camFlag = false
                uploadFlag = false
            }else{
                if uploadFlag == true{
                    if isStarting {
                        uploadCam(camC)
                        //print("taimer")
                    }
                    uploadFlag = false
                }else{
                    uploadFlag = true
                }
                
            }
        }
    }
    
    func setStartButtonState() {
        if isStarting {
            startButton.setTitle("Stop", for: UIControlState())
            startButton.backgroundColor = UIColor.red
        } else {
            startButton.setTitle("Start", for: UIControlState())
            startButton.backgroundColor = originalButtonColor!
        }
    }
    
    @IBAction func pushedWebButton(_ sender: Any) {
        let url = URL(string: kPresentUrl)
        if UIApplication.shared.canOpenURL(url!){
            if #available(iOS 10.0, *) {
                UIApplication.shared.open(url!, options: [:], completionHandler: nil)
            } else {
               UIApplication.shared.openURL(url!)
            }
        }
    }
    
    func startUpdating() {
        locationManager.startUpdatingLocation()
        locationManager.startUpdatingHeading()
        isUpdating = true
    }
    
    func stopUpdating() {
        locationManager.stopUpdatingLocation()
        locationManager.stopUpdatingHeading()
        isUpdating = false
    }
    
    func startTimerIfNeeded() {
        // タイマーをセット
        let pattern = TerminatePattern(rawValue: timeSegmentedControl.selectedSegmentIndex)!
        if pattern == TerminatePattern.non {
            return
        }
        var time = kTerminatingSeconds
        if pattern == TerminatePattern.selection {
            var diffSeconds = terminatingDate.timeIntervalSince(Date())
            if diffSeconds < 0 {
                diffSeconds += 60 * 60 * 24
            }
            time = diffSeconds
        }
        timer = Timer.scheduledTimer(timeInterval: time, target: self, selector: #selector(MainViewController.onStop(_:)), userInfo: nil, repeats: false)
        print("Will stop after \(time) seconds")
    }
    
    func stopTimerIfNeeded() {
        // タイマーを破棄
        if let _timer = timer {
            _timer.invalidate()
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        var statusStr: String
        switch (status) {
        case .notDetermined:
            statusStr = "NotDetermined"
            locationManager.requestAlwaysAuthorization()
        case .restricted:
            statusStr = "Restricted"
        case .denied:
            statusStr = "Denied"
        case .authorizedAlways:
            statusStr = "AuthorizedAlways"
            startUpdating()
        case .authorizedWhenInUse:
            statusStr = "AuthorizedWhenInUse"
            startUpdating()
        }
        print("CLAuthorizationStatus: \(statusStr)")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateHeading newHeading: CLHeading) {
        rotation = (newHeading.trueHeading > 0) ? newHeading.trueHeading : newHeading.magneticHeading
        rotationAccuracy = newHeading.headingAccuracy
    }
    /*
    func locationManager(_ manager: CLLocationManager, didUpdateLocations
        newLocations: [CLLocation], fromLocation oldLocation: CLLocation) {
        let cam = Cam(lat: newLocation.coordinate.latitude, lng: newLocation.coordinate.longitude, horizontalAccuracy: newLocation.horizontalAccuracy, alt: newLocation.altitude, verticalAccuracy: newLocation.verticalAccuracy, speed: newLocation.speed, rotation: rotation, rotationAccuracy: rotationAccuracy)
        infoLabel.text = cam.toString()
        //print(cam.toDictionary())
        print("locationManager Send")
        if isStarting {
            uploadCam(cam)
        }
    }
    */
    func locationManager(_ manager: CLLocationManager, didUpdateLocations
        locations: [CLLocation]) {
        guard let newLocation = locations.last else{
            return
        }
        let cam = Cam(lat: newLocation.coordinate.latitude, lng: newLocation.coordinate.longitude, horizontalAccuracy: newLocation.horizontalAccuracy, alt: newLocation.altitude, verticalAccuracy: newLocation.verticalAccuracy, speed: newLocation.speed, rotation: rotation, rotationAccuracy: rotationAccuracy)
        camC = cam
        infoLabel.text = cam.toString()
        //print(cam.toDictionary())
        camFlag = true
        if isStarting {
            uploadCam(cam)
        }
    }
    
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error){
        print("error")
    }
    
    func uploadCam(_ cam: Cam) {
        Alamofire.request(kBaseUrl + "cam/create", method: .post, parameters: cam.toDictionary()).responseObject { (response: DataResponse<CamCreateResponse>) in
//            let camCreateResponse = response.result.value
//            if camCreateResponse!.success {
//                return
//            }
        }
    }
    func onStop(_ sender: Any) {
        print("onStop")
        isStarting = false
        stopUpdating()
        stopTimerIfNeeded()
        setStartButtonState()
    }
}
