#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# python drive.py "origin" ["waypoint" ... ] "destination"
#
# ref. http://d.hatena.ne.jp/basuke/20120902/1346627868

import sys, json, urllib2, md5, os, os.path, pprint, random, generateroute
from math import radians, sin, cos, atan2, pow, sqrt, degrees
from urllib import quote_plus
from xml.sax.saxutils import escape
from optparse import OptionParser

CACHE_DIR  = "GoogleDirectionCache"
OUTPUT_DIR3 = "GoogleBaseStationData"





# 今出川キャンパス周辺(御池)
# OUTPUT_DIR = "GoogleDirectionData2_"
# 御池：　35.010927, 135.751778
# 百万遍：35.028805, 135.779250
#MIN_LAT =  35.010927
#MAX_LAT =  35.028805
#MIN_LNG = 135.751778
#MAX_LNG = 135.779250

#今出川キャンパス周辺（丸太町）
#MIN_LAT = 35.017361
#MAX_LAT = 35.033537
#MIN_LNG = 135.752107
#MAX_LNG = 135.780468

#祇園四条-烏丸御池周辺
MIN_LAT = 35.000161
MAX_LAT = 35.010989
MIN_LNG = 135.752078
MAX_LNG = 135.772358


# 今出川キャンパス周辺(御所)
# MIN_LAT =  35.017238
# MAX_LAT =  35.029300
# MIN_LNG = 135.757857
# MAX_LNG = 135.769916


# 渋谷駅周辺
# MIN_LAT =  35.6559722
# MAX_LAT =  35.6609694
# MIN_LNG = 139.6982763
# MAX_LNG = 139.7036578

# 今出川キャンパス周辺
# MIN_LAT =  35.0172260
# MAX_LAT =  35.0383510
# MIN_LNG = 135.7512990
# MAX_LNG = 135.7697370

# 石川県珠洲市役所周辺
#MIN_LAT =  37.431332
#MAX_LAT =  37.438351
#MIN_LNG = 137.256714
#MAX_LNG = 137.267477

#車両数
ID_CNT  = 10

#BaseStationData
Cmemory = [] #stepのlat,lngの保存、communication状態
firstflag = 0

def generateRandomLatLngStr():
    #指定した範囲内の緯度、経度をランダムで出した値を"緯度,経度"の形で返す
    return "%f,%f" % (random.uniform(MIN_LAT, MAX_LAT), random.uniform(MIN_LNG, MAX_LNG))

#origin=出発地 destination=目的地　ルート検索用のurlを作るメソッド
def createUrlForDirection(origin, destination):
    #出発地と目的地パラメータでルート検索を出してくれるurl(google maps api -> route api -> direction)
    #httpsに変更
    url = "https://maps.googleapis.com/maps/api/directions/json?origin=%s&destination=%s&sensor=false&key=AIzaSyCB2XZLd6qL68XM4Rxnby0KQYvwuI3KGTY"
    #urlのパラメータに出発地と目的地の情報を入れる
    #quote_plus クエリ文字列をurlに入れるためにHTML用の文字列の形にする機能（空白は＋を入れてくれる）
    url = url % (quote_plus(origin), quote_plus(destination)) 
    #urlを返す
    return url


#キャッシュファイルの取得(経路情報の入ったキャッシュ(urlからの返事))
def getCachePath(url):
    #キャッシュディレクトリ（GoogleDirectionCathe）がなかったらキャッシュディレクトリを作る
    if not os.path.isdir("./" + CACHE_DIR):
        os.makedirs(CACHE_DIR)
    #urlをハッシュ化したものに該当するキャッシュディレクトリ下のjsonファイルの場所を返す
    return "./" + CACHE_DIR + '/' + md5.new(url).hexdigest() + '.json' #

#経路情報の入手
def fetchDirection(url):
    data = None
    cache_path = None
    fetched = False

    #urlからキャッシュファイルの取得
    cache_path = getCachePath(url)

    #キャッシュファイルが存在したら
    if os.path.isfile(cache_path):

        #キャッシュファイルの中身をdataに入れる
        with file(cache_path, 'r') as fp:
            data = json.load(fp)

    #dataがない（キャッシュファイルの中身がなかったら）
    if not data:
        #urlから直接データを取ってきてdataに入れる
        fp = urllib2.urlopen(url)
        data = json.load(fp)
        fp.close()
        #fechedをTrueにする
        fetched = True

    #fechedがTrue(キャッシュファイル自体はあったが中身がなかった）のとき
    if fetched:
        #キャッシュファイルに先ほどurlから直接取ってきたデータを書き込む
        fp = file(cache_path, 'w')
        json.dump(data, fp)
        fp.close()

    #キャッシュファイルの中身のstatusがokでなかったらエラーを出す
    #キャッシュファイルの中身に関しては以下参照
    #https://qiita.com/oyuno_hito/items/69531fcc4b133dfea205
    #https://developers.google.com/maps/documentation/directions/intro
    #https://qiita.com/kngsym2018/items/15f19a88ea37c1cd3646
    if data.get('status') != 'OK':
        error('Bad data')

    #route->経路ごとに配列に詳細がjson形式で格納
    route = data['routes'][0]
    #route->legs->距離、時間、始点及び終点の住所と緯度経度、経路が格納
    return route['legs']

def output2(conpaths):
    #OUTPUTDIR(GooleDirectionData)がなかったらそのディレクトリを作る
    if not os.path.isdir("./" + OUTPUT_DIR3):
        os.makedirs(OUTPUT_DIR3)
    
    #OUTPUTDIRのファイルを開いて書き込み
    f = open("./" + OUTPUT_DIR3 + "/connectable.txt", 'w')
    #経路ポイントの書き込み（緯度   経度    角度    速度)の形で
    for conpath in conpaths:
        #pow()->べき乗
        conpath[0] = int(conpath[0] * pow(10, 6))
        conpath[1] = int(conpath[1] * pow(10, 6))
        line = str(conpath[0]) + '\t' + str(conpath[1]) + '\t' + str(conpath[2]) + '\n'
        #line = '%(lat)d\t%(lng)d\t%(rotation)d\t%(speed)d\t%(pathid)d\n' % step
        f.write(line)
    f.close()


#車両ID
sid = 1
while(sid <= ID_CNT):
    #出発地（"緯度,経度")
    origin = generateRandomLatLngStr()
    #目的地("緯度,経度")
    destination = generateRandomLatLngStr()
    #"出発地の緯度,出発地の経度 => 目的地の緯度,目的地の経度"の出力
    print ("%s => %s" % (origin, destination))
    #経路を得るためのurlの作成
    url = createUrlForDirection(origin, destination)
    try:
        #urlで返されたデータの中のlegsの情報(距離、時間、始点及び終点の住所と緯度経度、経路が格納)をlegsに入れる
        legs   = fetchDirection(url)
        #秒単位での経路情報（緯度、経度、速度、角度の変化)が入ってる配列をpointsに入れる
        proute = generateroute.getRoutedata(legs)
        if firstflag == 0:
            fcnt1 = 0
            for route in proute:
                if fcnt1 != 0 :
                    Cmemory.append([route['slat'], route['slng'], random.randint(0,1)])
                fcnt1 = 1
            #Cmemory.append([proute[-1]['glat'],proute[-1]['glng'], random.randint(0,1)])
            firstflag = 1
        else:
            doubleflag = 0
            fcnt2 = 0
            for route in proute:
                if fcnt2 != 0:
                    for Cmemo in  Cmemory:
                        if route['slat'] == Cmemo[0] and route['slng'] == Cmemo[1]:
                            doubleflag = 1    
                    if doubleflag == 0:      
                        Cmemory.append([route['slat'], route['slng'], random.randint(0,1)])
                fcnt2 = 1
            doubleflag = 0
            #for Cmemo in  Cmemory:
                #if proute[-1]['glat'] == Cmemo[0] and proute[-1]['glng'] == Cmemo[1]:
                    #doubleflag = 1
            #if doubleflag == 0:
               # Cmemory.append([proute[-1]['glat'], proute[-1]['glng'], random.randint(0,1)])
        sid += 1
    except:
        print("error")
        pass
#print(Cmemory)
output2(Cmemory)
#print 'done'
print("done")