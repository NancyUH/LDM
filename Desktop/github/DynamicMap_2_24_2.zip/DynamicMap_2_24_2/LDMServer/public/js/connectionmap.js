
var map;
var stationDic = {};
var routeDic = {};
var cmarkerDic = {};
var maxLat =  -90.0;
var minLat =   90.0;
var maxLng = -180.0;
var minLng =  180.0;
var isInited = false;
var tLat, tLng;
var alertStations     = [];
var dangerousStations = [];
var useCentralMode = true;
var alertCircle = null;
var useAlertCircle = true;
var timeDic = [];
var tflag = 0;
var nearid;
var issid1 = [];
var issid2 = {};

//api.jsのcam情報を使う
//cam情報からのマーカーの作成とstationDicの'maker'の登録、警告の処理
function displayMarker(cam) {
  var sid    = cam.station.sid;
  var key    = String(sid);
  var marker = null;
  
　//stationDic内にkeyがあり、かつStationDic[key]内に'maker'がある場合
  if (key in stationDic && 'marker' in stationDic[key]) {
    //makerにstationDic[key]['maker']情報を入れる
    marker = stationDic[key]['marker'];
  } else {
    //makerにstationDic[key]にcamを入れる
    stationDic[key] = cam;
    //マーカーアイコン(オブジェクト）の作成(commmn.jsのmakeMaker)
    //mapは初期はcommon.jsのinitMapで設定
    marker = makeMarker(map, sid, cam.stype, cam.lat, cam.lng);
  }

  // 距離を算出し、アラートを出す
  //isAlertMode->route/index.jsのパラメータ
  if (isAlertMode) {
    //tid->route/index.jsのパラメータ
    //camのidとパラメータのidが同じなら
    if (sid == tid) {
      //tLat,tLngにそれぞれcamの緯度経度を代入
      tLat = cam.lat;
      tLng = cam.lng;
      //tLatLngオブジェクトを作る
      var tLatLng = new google.maps.LatLng(tLat, tLng);
      // 中心モードの場合は、地図の中心を更新
      // setCenterを使うとマーカーが途中から消えるバグがあるので注意
      // https://code.google.com/p/gmaps-api-issues/issues/detail?id=5716
      //presemt.ectの中心表示モードがONになってるとき
      if (useCentralMode) {
        //地図の中央に表示、位置座標を絶対的に移動させる（中央表示）
        map.panTo(tLatLng);
      }
      // 警告範囲の表示
      //presemt.ectの警告範囲の表示がONになってるとき
      if (useAlertCircle) {
        //alertCircleがnull(初期)のとき
        if (alertCircle == null) {
          //makrAlertCircle(common.js)を呼び出す
          //円の作成
          alertCircle = makeAlertCircle(map);
        }
        //円の中心の座標の設定
        alertCircle.setCenter(tLatLng);
      } else {
        //警告範囲の表示がoffの時は経度緯度が0,0のところを中心にする
        alertCircle.setCenter(new google.maps.LatLng(0, 0));
      }
    //camのidとパラメータのidが違う時
    } else {
      // camのidとパラメーターのidとの距離を算出し、必要に応じてアラートを出す
      // アラートを出す必要がない場合は、リストから消す
      //handlealert->commmon.js
      //isAlertの設定もあり
      handleAlert(sid, cam.lat, cam.lng, tLat, tLng, alertStations, dangerousStations);
    }
  }
　//maker内のiconの更新（警告時や通常時、タイプ)
//common.jsにある
  setIconForMarker(marker, cam.stype, cam.lat, cam.lng, cam.rotation, cam.speed);
  //stationDic[key]['marker']にmarkerを入れる（新規作成or更新）
  stationDic[key]['marker'] = marker; // dicに格納
}


function updateCornerLatLng(cam) {
  //はみ出し防止
  if (cam.lat > maxLat) maxLat = cam.lat;
  if (cam.lat < minLat) minLat = cam.lat;
  if (cam.lng > maxLng) maxLng = cam.lng;
  if (cam.lng < minLng) minLng = cam.lng;
}

//jsonファイルの取得
function getJson(url){
  return JSON.parse($.ajax({
    type: 'GET',
    url: url,
    dataType: 'json',
    global: false,
    async: false,
    success: function (data) {
        return data;
    }
  }).responseText);
}

//経路の表示
function displayRoutes(route){
  var dsid = route.station.sid;
  var drid = route['rid'];
  var slat = route['slat'];
  var slng = route['slng'];
  console.log('rid = %d, slat = %f, slng = %f',drid,slat,slng);
  var encoded_path = route['polyline'];
  var decoded_path = google.maps.geometry.encoding.decodePath(encoded_path);
  makeRmarker(dsid,drid,decoded_path); 
    
}

function redisplayRoutes(){
  var routejson = getJson('/api/allroute/fetch');
  for(var i = 0; i<routejson.length; i++){
    var dsid = routejson[i]['station']['sid'];
    var drid = routejson[i]['rid'];
    var encoded_path = routejson[i]['polyline'];
    var decoded_path = google.maps.geometry.encoding.decodePath(encoded_path);
    makeRmarker(dsid,drid,decoded_path); 
  }   
}

//経路ポリラインの表示
function makeRmarker(sid,rid,path){
  //var color = ["#00ff00","#ff00ff","#00ffff","#ff0000","#0000ff","#ffff00"];
  //crnd = Math.floor( Math.random() * 5 );
  var polyline = null;
  var key = String(sid);
  var rkey = String(rid);
  if(key in routeDic){
    if(rkey in routeDic[key]){
    }else{
      routeDic[key][rkey] = {};
    }
  }else{
    routeDic[key] = {};
    routeDic[key][rkey] = {};
  }
  var polyOptions = 
    {
        path: path , 
        strokeColor: "#0000ff", //線色
        strokeOpacity: 0.7 , //透明度0.0-1.0 
        strokeWeight: 10 ,//幅pixel 
        map: map
    }
  polyline = new google.maps.Polyline(polyOptions);
  polyline.setMap(map);
  routeDic[key][rkey]['polyline'] = polyline;
  
}

//基地局マーカーの表示
//-------------------------------------------------------------
function displayBaseStation(BSdata){
  var convertedlat = BSdata['lat'] ;
  var convertedlng = BSdata['lng'] ;
  var BSid = BSdata['BSid'];
  //var rdistance = BSdata['distance'];
  makeCmarker(convertedlat,convertedlng,BSid);        
}

function displayCdistance(dtbs){
  var convertedlat = dtbs['lat'] ;
  var convertedlng = dtbs['lng'] ;
  var BSid = dtbs['BSid'];
  var rdistance = dtbs['distance'];
  //makeCArea(convertedlat,convertedlng,BSid,rdistance);
}
//マーカーの再表示
function redisplayBaseStation(){
  var BSdatajson = getJson('/api/BaseStation/fetch');
  for(var i = 0; i < BSdatajson.length; i++){
    var convertedlat = BSdatajson[i]['lat'] /= Math.pow(10, 6);
    var convertedlng = BSdatajson[i]['lng'] /= Math.pow(10, 6);
    var BSid = BSdatajson[i]['BSid'];
    var rdistance = BSdatajson[i]['distance'];
    makeCmarker(convertedlat,convertedlng,BSid,rdistance);    
  }       
}

function redisplayCdistance(){
  var BSDistancejson = getJson('/api/BSDistance/fetch');
  for(var i = 0; i < BSDistancejson.length; i++){
    var convertedlat = BSDistancejson[i]['lat'] /= Math.pow(10, 6);
    var convertedlng = BSDistancejson[i]['lng'] /= Math.pow(10, 6);
    var BSid = BSDistancejson[i]['BSid'];
    var rdistance = BSDistancejson[i]['distance'];
    //makeCArea(convertedlat,convertedlng,BSid,rdistance);    
  }       
}

//マーカーの作成　クリックしたら緯度経度表示
function makeCmarker(lat,lng,BSid){
  var marker = null;
  var markerPosition ={lat:lat,lng:lng};
  var cicon = null;
  var key = String(BSid);

  if(key in cmarkerDic){
  }else{
    cmarkerDic[key] = {};
  }

  cicon = {
    url: 'https://lh3.googleusercontent.com/DtMN0miaeOcie-TNa9WWUE2Y-NxMd4iiaiYnhSOOQK83_JjSFdIVbr08PzZNjn1sjWhgqHELvIuZNMmu_saZ4R3EInh3wneB5CloeZTFsw-xHDUh_tmiikC9almY2HRfsNzrZ3fYixty0EeN9StxqBMxRg8t1XS3qn11o2yjmYnU6W2PjH9KklY7YHPiQFKXmoA57Hv1BdXWafCYT85KXWMR8vBqCzFRwFwtNXuoRa38QYup2zEpxs9MpirJ6CjII45EsOCWDYDvbdDjR_Nb0nDzEEVygnVnn9LAbhT7BIC4QiBPs8ezHAdK2-J5eq9QvKswOVtlVtUYMry69bXtuamNc_rUOyuCzafFUj7JVfJJxB91KWtPYQVg5KttWb0YlxmFjFeVOeDKKOchhECjPhKDo_8CTGNuqnJ0zf1frbPthz2RmAhyZUg7oKcPxsZ4_JcNYNQCDdnFBb3yHhtlYieXKJr6PHz0gnIiGWEKDe-VVDMf6KieJy5qGmXXcyH5iKNCp0iN-iotgIGJjRxDoREglRCYlHSQMxh04xZ3F7LPf7YIC9whz8nYLiO_M8y5BfPZDuyojsDyJL5war2qxfRNOs4urz2VNVyB3563pS8sWEpNJV3eVGFwT1QbOIMW2y6eqH0j4ItXRMfknYbncBuD9raB75TUbnLwn-_VBm2ISmfEYWnE7XM=s256-no',
    scaledSize: new google.maps.Size(40,40)
  };

  marker = new google.maps.Marker({
    position  : markerPosition,
    map       : map,
    icon      : cicon,
    optimized : false
  });
  var infoWindow = new google.maps.InfoWindow({
    content : 'lat : '+ lat + ' lng : ' + lng
  });
  marker.addListener('click',function(){
    infoWindow.open(map, marker);
  });
  cmarkerDic[key]['marker'] = marker;
}

function makeCArea(lat,lng,BSid,rdistance){
  var key = String(BSid);

  if(key in cmarkerDic){
    if('circle' in cmarkerDic[key]){
        circleObj = cmarkerDic[key]['circle'];
        circleObj.setMap(null);
    }
  }else{
    cmarkerDic[key] = {};
  }

  circleObj = makeCAreaCircle(map, lat, lng, rdistance);
  cmarkerDic[key]['circle'] = circleObj;
  circleObj.setMap(map);
}
//-------------------------------------------------------------


/*
//車両がノードの近くにいるか判定
function nowNode(cam){
  sid = cam.station.sid;
  //jsonファイルの呼び出し（経路情報）
  
  //経路情報の詳細[sid][routes][経由地番号(ikey)]
  //'rid'       : route.rid,
  //      'slat'      : convertedsLat,
  //      'slng'      : convertedsLng,
  //      'glat'      : convertedgLat,
  //      'glng'      : convertedgLng,
  //      'stime'     : route.stime,
  //      'gtime'     : route.gtime,
  //      'polyline'  : route.polyline,
  
  var sortjson = getJson('/api/route/fetch');
  var key = String(sid);
  var keysortjson = sortjson[key]['routes'];
  for(var i = 0; i < keysortjson.length; i++){
    var ikey = String(i);
    //車と経由地の距離
    var distance = getDistance(cam.lat, cam.lng, keysortjson[ikey]['slat'], keysortjson[ikey]['slng']);
    //距離0の時
    if(distance == 0){
      //その経由地番号をnearidに入れる
      //sidがissid2の中にすでに作られていたら(issid2->各Sidごとにすでに通過済みの経由地が入っている)
      nearid = keysortjson[ikey]['rid']; 
      if(key in issid2 == true){   
       var len = issid2[key].length;
       //nearridがissid2の最後に入っている経由地番号（最後に通った経由地番号）の次の番号だったら
       if(nearid == (issid2[key][len-1] + 1)){
        //issid2に新たに追加する
        issid2[key].push(nearid);
        //conBSdata(基地局アイコンがあるかどうかのメソッドに飛ぶ)
        //ComBSdata(sid,nearid);
        nearBS(sid,nearid);
       }
      //issid2の中にsidがまだ作られてなかったら
      }else{
        //新たに作ってその中に通過ずみ経由地番号を追加する
        issid2[key] = [];
        issid2[key].push(nearid);
        //基地局アイコンがあるかどうかのメソッドにとぶ
        //ComBSdata(sid,nearid);
        nearBS(sid,nearid);
      }     
      break;
    }
    //経由地の最後（目的地の場合はglatの方でも調べる）
    if(i == keysortjson.length - 1){
      var distance2 = getDistance(cam.lat, cam.lng, keysortjson[ikey]['glat'], keysortjson[ikey]['glng']);
      if(distance2 == 0){
        nearid = keysortjson[ikey]['rid']; 
        if(nearid == (issid2[key][len-1] + 2)){
          //ComBSdata(sid,nearid);
          nearBS(sid,nearid);
        }
      }
    }
  } 
}
*/

function nowBSposition(cam){
  var BSdatajson = getJson('/api/BaseStation/fetch');
  var dtbsjson = getJson('/api/BSDistance/fetch');
  for(var i = 0; i < BSdatajson.length; i++){
    var ikey = String(i);
    var convertedcmlat = BSdatajson[ikey]['lat'] / Math.pow(10, 6);
    var convertedcmlng = BSdatajson[ikey]['lng'] / Math.pow(10, 6);
    var distance2 = getDistance(cam.lat, cam.lng, convertedcmlat, convertedcmlng);
    console.log("dtbsdistance = %d", distance2);
    if(distance2 <= 1){
      for(var j = 0; j < dtbsjson.length; j++){
        var jkey = String(j);
        if(BSdatajson[ikey]['BSid'] == dtbsjson[jkey]['BSid']){
          dcnt++;
        }
      }
      console.log("dcnt = %d", dcnt);
      if(dcnt == 0){
        var rdistance = 1 + Math.floor( Math.random() * 100 );
        console.log('BSid = %d',BSdatajson[ikey]['BSid']);
        makeCAreaCircle(map, convertedcmlat, convertedcmlng, rdistance);
        $.ajax({
          async: false,
          type: 'post',
          url: 'http://'+ location.host +'/api/BSDistance/create',
          data: {
                "BSid" : BSdatajson[ikey]['BSid'],
                "distance" : rdistance,
                "lat" : BSdatajson[ikey]['lat'],
                "lng" : BSdatajson[ikey]['lng'],
                },
          dataType: 'json'
        });
      }  
    }
  }
}
//--------------------------------------------------------------------------------------


//基地局の通信可能範囲に入ったかどうか
function isBaseStationCircle(cam){
  var sid = cam.station.sid;
  var distancejson = getJson('/api/BSDistance/fetch');
  console.log(distancejson);
  //BaseStation/fetch から引き抜き　-> BSid, distance, lat ,lng,
  var flag = 0;
  for(var i = 0; i < distancejson.length; i++){
    var ikey = String(i);
    var BSlat = distancejson[ikey]['lat'] / Math.pow(10, 6);
    var BSlng = distancejson[ikey]['lng'] / Math.pow(10, 6);
    var BSdistance = distancejson[ikey]['distance'];
    var distance = getDistance(cam.lat, cam.lng, BSlat, BSlng);
    console.log("distance = %d", distance);
    if(distance <= BSdistance){
      console.log("*distance = %d, BSdistance = %d", distance, BSdistance);
      $("#sidnearstate"+ sid).html('<p><font color ="red">'+'通信可能場所です' + '</font></p>');
      flag = 1;
      break;
    }else{
      $("#sidnearstate"+ sid).html('<p><font color ="red">'+'' + '</font></p>');
    }
  }
  
}

//現在通過したノードに基地局があるかどうか
/*
function nearBS(sid,rid){
  var sortjson = getJson('/api/route/fetch');
  var BSdatajson = getJson('/api/BaseStation/fetch');
  var dtbsjson = getJson('/api/BSDistance/fetch');
  var key = String(sid);
  //var connectflag;
  var keysortjson = sortjson[key]['routes'];
  rkey = String(rid);
  for(var j = 0; j < BSdatajson.length; j++){
    var jkey = String(j);
    var convertedcmlat = BSdatajson[jkey]['lat'] / Math.pow(10, 6);
    var convertedcmlng = BSdatajson[jkey]['lng'] / Math.pow(10, 6);
    var distance2 = getDistance(keysortjson[rkey]['slat'], keysortjson[rkey]['slng'], convertedcmlat, convertedcmlng);
    //現在通過したノードに基地局がある場合
    //通信可能範囲を取得する
    if(distance2 == 0){
      console.log('sid = %d, rid = %d, 距離 = %d', sid, rid, distance2);
      //ここに通信範囲の新規作成をする
      //var rdistance = 1 + Math.floor( Math.random() * 100 );
      //console.log('rdistance = %d', rdistance);
      //makeCAreaCircle(map, convertedcmlat, convertedcmlng, rdistance);
      //取得した通信可能範囲をデータベースに格納する
      for(var i = 0; i < dtbsjson.length; i++){
        var ikey = String(i);
        if(BSdatajson[jkey]['BSid'] == dtbsjson[ikey]['BSid']){
          var rdistance = 1 + Math.floor( Math.random() * 100 );
          makeCAreaCircle(map, convertedcmlat, convertedcmlng, rdistance);
          $.ajax({
            async: false,
            type: 'post',
            url: 'http://'+ location.host +'/api/BSDistance/create',
            data: {
                  "BSid" : BSdatajson[jkey]['BSid'],
                  "distance" : rdistance,
                  "lat" : BSdatajson[jkey]['lat'],
                  "lng" : BSdatajson[jkey]['lng'],
                  },
            dataType: 'json'
          });
        }
      }
      
      break;
    }

  }
}
*/

//------------------------------------------------------------------------------------------------------------------------

/*
//ノード上にcflagがあるかどうか確認(2つ先のノードまで)
function ComBSdata(sid,rid){
  var sortjson = getJson('/api/route/fetch');
  var BSdatajson = getJson('/api/BaseStation/fetch');
  var key = String(sid);
  //var connectflag;
  var list = [];
  var keysortjson = sortjson[key]['routes'];
  for(var p = 0; p < 3; p++){
    var rkey = String(rid + p);
    if((rid + p) > keysortjson.length){
      list.push([sid,2,1,0,0,rid,0]);
      //list.push([sid,1,0,0,rid,0]);
    }else if((rid + p) == keysortjson.length){
      var rkey2 = String(keysortjson.length - 1);
      var isflag = 0;
      for(var i = 0; i < BSdatajson.length; i++){
        var ikey = String(i);
        var convertedcmlat = BSdatajson[ikey]['lat'] / Math.pow(10, 6);
        var convertedcmlng = BSdatajson[ikey]['lng'] / Math.pow(10, 6);
        var distance1 = getDistance(keysortjson[rkey2]['glat'], keysortjson[rkey2]['glng'], convertedcmlat, convertedcmlng);
        if(distance1 == 0){
          isflag = 1;
          //connectflag = BSdatajson[ikey]['cflag'];
          //3番目：rid外　７番目：到着点かどうか
          list.push([sid, 1, 0, keysortjson[rkey2]['glat'], keysortjson[rkey2]['glng'], rid, 1]);
          //list.push([sid, 0, keysortjson[rkey2]['glat'], keysortjson[rkey2]['glng'], rid, 1]);
          break;
        }
      }
      if(isflag == 0){
        list.push([sid, 2, 0, keysortjson[rkey2]['glat'], keysortjson[rkey2]['glng'], rid, 1]);
        //list.push([sid, 0, keysortjson[rkey2]['glat'], keysortjson[rkey2]['glng'], rid, 1]);
      }
    }else{
      var isflag2 = 0;
      for(var j = 0; j < BSdatajson.length; j++){
        var jkey = String(j);
        var convertedcmlat = BSdatajson[jkey]['lat'] / Math.pow(10, 6);
        var convertedcmlng = BSdatajson[jkey]['lng'] / Math.pow(10, 6);
        var distance2 = getDistance(keysortjson[rkey]['slat'], keysortjson[rkey]['slng'], convertedcmlat, convertedcmlng);
        if(distance2 == 0){
          //console.log('sid = %d, rid = %d, 距離 = %d', sid, rid + p, distance2);
          isflag2 = 1;
          //connectflag = BSdatajson[jkey]['cflag'];
          list.push([sid, 1, 0, keysortjson[rkey]['slat'], keysortjson[rkey]['slng'],rid,0]);
          //list.push([sid, 0, keysortjson[rkey]['slat'], keysortjson[rkey]['slng'],rid,0]);
          break;
        }
      }
      if(isflag2 == 0){
        list.push([sid, 2, 0, keysortjson[rkey]['slat'], keysortjson[rkey]['slng'],rid,0]);
        //list.push([sid, 0, keysortjson[rkey]['slat'], keysortjson[rkey]['slng'],rid,0]);
      }
    }    
  }
  labelNextnode(list);
}

function labelNextnode(list){
  var connectstate = [];
  var flag = 0;
  
  //console.log('----sid = %d----',list[0][0]);
  
  for(var i = 0; i < 3; i++){
    if(list[i][2] == 1){
      connectstate.push('到着しています');
      //console.log('到着しています');
    }else{
      if(list[i][1] == 0){
        connectstate.push('通信不可');
        //console.log('通信不可');
  
      }else if(list[i][1] == 1){
        connectstate.push('通信可能');
        //console.log('通信可能');
  
      }else{
        connectstate.push('情報がありません');
        //console.log('該当なし');
      }
    }
  }
  
  //var nodestate1 = '--今のノード--' + '<br>'+ connectstate[0];
  var nodestate2 = '--次のノード--' + '<br>'+ connectstate[1];
  var nodestate3 = '--2つ先のノード--' + '<br>'+ connectstate[2];
  //var state = '<p>' + nodestate1 + '<br>'+ nodestate2 + '<br>' + nodestate3 + '</p>';
  var state = '<p>' + nodestate2 + '<br>' + nodestate3 + '</p>';
  $("#sidnewstate"+ list[0][0]).html(state);
  */
  /*
  if(list[0][2] == 0 && list[0][1] == 2 && list[0][5] != 0 && list[0][6] == 0){
    var lat = list[0][3] * Math.pow(10, 6);
    var lng = list[0][4] * Math.pow(10, 6);
    //console.log('BSid = %d, lat = %f, lng = %f',list[0][1],lat,lng);
    $.ajax({
      async: false,
      type: 'post',
      url: 'http://'+ location.host +'/api/BaseStation/create',
      data: {"lat" : lat,
            "lng" : lng,
            "cflag" : Math.floor( Math.random() * (1 + 1 - 0) ) + 0
            },
      dataType: 'json'
    });

  }
  */

//}

function initConnectnode(cam){
  var flag = 0;
  var sid = cam.station.sid;
  var newnodestate = '<div class="col-lg-3 col-md-3 col-sm-4 col-xs-6">' +'----sid =' + sid +'----' + '<div id = sidnearstate'+ sid + '>' +'</div>' + '<div id = sidnewstate'+ sid + '>' + sid +'の情報が入ります </div>' + '</div>';
  if(issid1.length == 0){
    issid1.push(sid);
    $("#nodeconnectflag").append(newnodestate);
  }else{
    for(var i = 0; i < issid1.length; i++){
      if(issid1[i] == sid){
        flag = 1;
        break;
      }
    }
    if(flag == 0){
      issid1.push(sid);
      $("#nodeconnectflag").append(newnodestate);
    }
  }
}

/*
function settimeDic(cam){
  var sid = cam.station.sid;
  if (tflag == 0){
    timenow = Date.now();
    timeDic.push([sid,cam.date,timenow]);
    tflag = 1;
  }else{
    var isflag = 0;
    for(var i = 0; i < timeDic.length; i++){
      if(timeDic[i][0] == sid){
          isflag = 1;
      }
    }
    if(isflag == 0){
      timenow = Date.now();
      timeDic.push([sid,cam.date,timenow])
    }
  }
}
*/

$(function(){
  // 警告モードの場合はデフォルトOFF
  //表示ステーション　"すべて"をOFF
  if (isAlertMode) {
    $('#all-check').prop('checked', false);
  }
  var socket = io.connect();

  //var myJsonObj = getJson('/api/allroute/fetch');
  //console.log(myJsonObj);

  socket.on('update3', function(BSdata){
    displayBaseStation(BSdata);
    //console.log('update3');
  });

  socket.on('update4', function(dtbs){
    displayCdistance(dtbs);
    //console.log('update4');
  });

  //setInterval(updateConnectionmap,5000);
  socket.on('update2', function(route){
    displayRoutes(route);
    //console.log('update2');
  });

  //画面更新(api.js)
  socket.on('update', function(cam){
    var sid = cam.station.sid;
    //settimeDic(cam);
    initConnectnode(cam);
    //nowNode(cam);
    nowBSposition(cam);
    isBaseStationCircle(cam);
    //redisplayRoutes();

    //sidがstationDicにある時
    // 凡例表示
    if (!(sid in stationDic)) {
      // 警告モードでかつ、ターゲットステーションの場合は、別表示にする
      if (isAlertMode && sid == tid) {
        //common.js target-stationの表示と更新（colorがない?)
        addTargetStationElem(cam.station.sname, cam.stype, sid);
      } else {
        // 凡例チェックボックス
        // 警告モードの場合は全てチェックを外す(警告対象にする)(colorがない？)
        addCheckboxElem(cam.station.sname, cam.stype, sid, !isAlertMode);
      }
    }
    
    //cam情報からのマーカーの作成とstationDicの'maker'の登録、警告の処理
    displayMarker(cam);
    //はみ出し防止
    updateCornerLatLng(cam);
    //警告モードの時
    if (isAlertMode) {
      // アラートを表示する(common.js)
      displayAlert(alertStations);
    }

    // 初回のみ地図の位置とズームの自動調整
    if (!isInited) {
      //マップの境界の設定とその境界がうまく写るように設定(common.js)
      fitBoundsForMap(map, minLat, maxLat, minLng, maxLng);
      isInited = true;
    }
    // TODO 一定期間動かないマーカーについては消す？
  });
});
//地図描画の実行(initMap(commomn.js)の呼び出し)
google.maps.event.addDomListener(window, 'load', initMap);

//use-central-mode(connectionmap.ect)が変化するたび発生するイベント
$('#use-central-mode').on("change", function() {
  useCentralMode = $(this).is(':checked');
  if (useCentralMode) {
    map.setZoom(MAX_ZOOM_LEVEL);
  } else {
    fitBoundsForMap(map, minLat, maxLat, minLng, maxLng);
  }
});

//use-alert-circle(connectionmap.ect)が変化するたび発生するイベント
$('#use-alert-circle').on("change", function() {
  useAlertCircle = $(this).is(':checked');
});

//refresh(connectionmap.ect)がクリックするたび発生するイベント
// 地図の位置とズームの自動調整
$("#refresh").on("click", function(){
  fitBoundsForMap(map, minLat, maxLat, minLng, maxLng);
});

//idのチェックボックスが変わるたびに発生するイベント
//id属性がcheckbox-と先頭一致
//https://qiita.com/Thought_Nibbler/items/5d4fc40a4d4325128b24
$(document).on("change", "[id^=checkbox-]", function() {
  //指定したidのマーカーを地図に配置
  setMapForMarker(stationDic, $(this).attr('sid'));
});

