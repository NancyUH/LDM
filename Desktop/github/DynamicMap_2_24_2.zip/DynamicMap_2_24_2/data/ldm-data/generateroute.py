#! /usr/bin/env python
# -*- coding: utf-8 -*-

def getRoutedata(legs):
    cnt = 0
    route =[]
    stime = 0
    gtime = 0
    for leg in legs:
        for step in leg['steps']:
            #startの中に'start_location'の情報を入れる(出発地の緯度経度情報が入ってる)
            start = step['start_location']
            #endの中に'end_location'の情報を入れる(目的地の緯度経度情報が入ってる)
            end = step['end_location']
            #durartionの中に'duration'の情報のうちの'value'を入れる(経過時間(s)が入っている)
            duration = step['duration']['value']
            polyline = step['polyline']
            gtime += duration
            rp = {
                    'rid'   :cnt,
                    'slat'  :start['lat'],
                    'slng'  :start['lng'],
                    'glat'  :end['lat'],
                    'glng'  :end['lng'],
                    'stime' :stime,
                    'gtime' :gtime,
                    'polyline' : polyline['points']
            }
            stime += duration
            cnt += 1
            route.append(rp)
    return route
