//
//  Cam.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/30.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import SwiftyUserDefaults

struct Cam {
    var protocolVersion: Int!
    var sid: Int!
    var stype: Int!
    var date: String!
    var lat: Int!
    var lng: Int!
    var alt: Int!
    var speed: Int!
    var rotation: Int!
    // アップロードしない
    var horizontalAccuracy: Int!
    var verticalAccuracy: Int!
    var rotationAccuracy: Int!
    
    init(lat: Double, lng: Double, horizontalAccuracy:Double, alt: Double, verticalAccuracy: Double, speed: Double, rotation:Double, rotationAccuracy:Double) {
        let now = Date()
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        
        self.protocolVersion    = kProtocolVersion
        self.sid                = Defaults[.sid]
        self.stype              = Defaults[.stype]
        self.date               = formatter.string(from: now)
        self.lat                = Int(lat * 1_000_000)
        self.lng                = Int(lng * 1_000_000)
        self.horizontalAccuracy = Int(horizontalAccuracy)
        self.alt                = Int(alt * 100) // m -> cm
        self.verticalAccuracy   = Int(verticalAccuracy)
        self.speed              = (speed > 0) ? Int(speed * 100) : 0 // m/sec -> cm/sec
        self.rotation           = Int(rotation * 10)
        self.rotationAccuracy   = Int(rotationAccuracy)
    }
    
    func toString() -> String {
        return  "lat:\(String(format: "%11d", lat)), lng :\(String(format: "%11d", lng)), accuracy :\(horizontalAccuracy!)\n" +
                "alt:\(String(format: "%6d", alt)), verticalAccuracy :\(verticalAccuracy!)\n" +
                "speed:\(String(format: "%5d", speed))\n" +
                "rotation:\(String(format: "%4d", rotation)), rotationAccuracy :\(rotationAccuracy!)"
    }
    
    func toDictionary() -> [String: Any] {
        return [
            "protocolVersion" : protocolVersion,
            "sid"             : sid,
            "stype"           : stype,
            "date"            : date,
            "lat"             : lat,
            "lng"             : lng,
            "alt"             : alt,
            "speed"           : speed,
            "rotation"        : rotation,
        ]
    }
}
