#! /usr/bin/env python
# -*- coding: utf-8 -*-
#stepの情報を送る順番に並べ直してURLにアップロードする
import os
import os.path
import math
import requests
import datetime
from collections import Counter
from time import sleep
import random

HOSTNAME  = "localhost"
PORT      = "3000"

URL3      = "http://" + HOSTNAME + ":" + PORT + "/api/BaseStation/create"
URL4      = "http://" + HOSTNAME + ":" + PORT + "/api/BSdistance/create"

DIR_PATH3 = './GoogleBaseStationData'
# リアルタイムにデータを送信する
# Trueの場合、現在時刻で、1秒ごとにデータを送信する
# Falseの場合、BASE_TIMEを基準にデータを送信する
IS_REALTIME = True
BASE_TIME = "2016-02-13T02:30:00.000"

def uploadBaseStationData():
    fileNames = os.listdir(DIR_PATH3)
    #print("fileNames="+str(fileNames))
    nodeDic = []
    nodeDic2 = []

    #fileNameを一つづつ見る
    for fileName in fileNames:
        #print("fileName"+str(fileName))
        #もし、fileNameの拡張子が.txtではなかったら飛ばす
        if not fileName.endswith(".txt"):
            continue

        #fileNameのファイルを開く
        f = open(DIR_PATH3 + '/' + fileName)
        #1行ごとに見る（行の情報はlineに）
        lines = f.readlines()
        #enurate()インデックス番号をつける-> timeにはインデックス番号　lineに行情報が入る形
        cnt1 = 0
        for line in lines:
            #改行コードをなくす
            line = line.replace('\n', '')
            #print(str(time)+":"+str(line))
            #タブコードで区切って中身を配列paramsに入れる
            #params[0] :緯度 params[1]:経度 params[2]:向きの変化　params[3]:速度
            params = line.split('\t')

            lat     = int(params[0])
            lng     = int(params[1])
            cflag   = int(params[2])
            distance1 = random.randint(0,100)
            if cflag == 1:
                #上記の情報をstepに入れつつ他の情報も追加
                node = {
                    'BSid'            : cnt1,
                    'lat'            : lat,    
                    'lng'            : lng,
                }
                dflag = random.randint(0,1)
                if dflag == 1:
                    node2 = { 
                        'BSid'            : cnt1,
                        'lat'            : lat,    
                        'lng'            : lng,
                        'distance'       : distance1,    
                    }
                    nodeDic2.append(node2)

                nodeDic.append(node)
                cnt1 += 1
    #経過時間で回す
    for node in nodeDic:
        res = requests.post(URL3, data=node)
        print ("uploaded: %d\t%d\t%d" % (node['BSid'], node['lat'], node['lng']))

        if IS_REALTIME :
           sleep(1)
    for node2 in nodeDic2:
        res = requests.post(URL4, data=node2)
        print ("uploaded: %d\t%d\t%d\t%d" % (node2['BSid'], node2['lat'], node2['lng'],node2['distance']))

        if IS_REALTIME :
           sleep(1)


    #print ('uploaded:all')

def main():
    uploadBaseStationData()

if __name__ == '__main__':
    main()