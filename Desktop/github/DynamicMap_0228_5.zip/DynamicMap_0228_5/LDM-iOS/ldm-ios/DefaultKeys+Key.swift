//
//  DefaultKeys+Key.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/30.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import SwiftyUserDefaults

extension DefaultsKeys {
    // Server settings
    static let host = DefaultsKey<String>("host");
    static let port = DefaultsKey<String>("port");
    
    // Station settings
    static let sid = DefaultsKey<Int?>("sid");
    static let sname = DefaultsKey<String>("sname");
    static let stype = DefaultsKey<Int>("stype");
    
    // App state
    static let isInited = DefaultsKey<Bool>("isInited");
}

func initUserDefaults() {
    Defaults[.host] = kHost
    Defaults[.port] = kPort
    Defaults[.sname] = "NoName"
    Defaults[.stype] = 1
}
