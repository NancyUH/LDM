#! /usr/bin/env python
# -*- coding: utf-8 -*-

#
# python drive.py "origin" ["waypoint" ... ] "destination"
#
# ref. http://d.hatena.ne.jp/basuke/20120902/1346627868

import sys, json, urllib2, md5, os, os.path, pprint, random, generateroute
from math import radians, sin, cos, atan2, pow, sqrt, degrees
from urllib import quote_plus
from xml.sax.saxutils import escape
from optparse import OptionParser

CACHE_DIR  = "GoogleDirectionCache"
# OUTPUT_DIR = "GoogleDirectionData"
OUTPUT_DIR = "GoogleDirectionData"
OUTPUT_DIR2 = "GoogleRouteData"






# 今出川キャンパス周辺(御池)
# OUTPUT_DIR = "GoogleDirectionData2_"
# 御池：　35.010927, 135.751778
# 百万遍：35.028805, 135.779250
#MIN_LAT =  35.010927
#MAX_LAT =  35.028805
#MIN_LNG = 135.751778
#MAX_LNG = 135.779250

#今出川キャンパス周辺（丸太町）
#MIN_LAT = 35.017361
#MAX_LAT = 35.033537
#MIN_LNG = 135.752107
#MAX_LNG = 135.780468

# 今出川キャンパス周辺(御所)
# MIN_LAT =  35.017238
# MAX_LAT =  35.029300
# MIN_LNG = 135.757857
# MAX_LNG = 135.769916

#祇園四条-烏丸御池周辺
MIN_LAT = 35.000161
MAX_LAT = 35.010989
MIN_LNG = 135.752078
MAX_LNG = 135.772358


# 渋谷駅周辺
# MIN_LAT =  35.6559722
# MAX_LAT =  35.6609694
# MIN_LNG = 139.6982763
# MAX_LNG = 139.7036578

# 今出川キャンパス周辺
# MIN_LAT =  35.0172260
# MAX_LAT =  35.0383510
# MIN_LNG = 135.7512990
# MAX_LNG = 135.7697370

# 石川県珠洲市役所周辺
#MIN_LAT =  37.431332
#MAX_LAT =  37.438351
#MIN_LNG = 137.256714
#MAX_LNG = 137.267477

#車両数
ID_CNT  = 1

def generateRandomLatLngStr():
    #指定した範囲内の緯度、経度をランダムで出した値を"緯度,経度"の形で返す
    return "%f,%f" % (random.uniform(MIN_LAT, MAX_LAT), random.uniform(MIN_LNG, MAX_LNG))

#origin=出発地 destination=目的地　ルート検索用のurlを作るメソッド
def createUrlForDirection(origin, destination):
    #出発地と目的地パラメータでルート検索を出してくれるurl(google maps api -> route api -> direction)
    #httpsに変更
    url = "https://maps.googleapis.com/maps/api/directions/json?origin=%s&destination=%s&optimizeWaypoints=true&sensor=false&key=AIzaSyCB2XZLd6qL68XM4Rxnby0KQYvwuI3KGTY"
    #urlのパラメータに出発地と目的地の情報を入れる
    #quote_plus クエリ文字列をurlに入れるためにHTML用の文字列の形にする機能（空白は＋を入れてくれる）
    url = url % (quote_plus(origin), quote_plus(destination)) 
    #urlを返す
    return url


#キャッシュファイルの取得(経路情報の入ったキャッシュ(urlからの返事))
def getCachePath(url):
    #キャッシュディレクトリ（GoogleDirectionCathe）がなかったらキャッシュディレクトリを作る
    if not os.path.isdir("./" + CACHE_DIR):
        os.makedirs(CACHE_DIR)
    #urlをハッシュ化したものに該当するキャッシュディレクトリ下のjsonファイルの場所を返す
    return "./" + CACHE_DIR + '/' + md5.new(url).hexdigest() + '.json' #

#経路情報の入手
def fetchDirection(url):
    data = None
    cache_path = None
    fetched = False

    #urlからキャッシュファイルの取得
    cache_path = getCachePath(url)

    #キャッシュファイルが存在したら
    if os.path.isfile(cache_path):

        #キャッシュファイルの中身をdataに入れる
        with file(cache_path, 'r') as fp:
            data = json.load(fp)

    #dataがない（キャッシュファイルの中身がなかったら）
    if not data:
        #urlから直接データを取ってきてdataに入れる
        fp = urllib2.urlopen(url)
        data = json.load(fp)
        fp.close()
        #fechedをTrueにする
        fetched = True

    #fechedがTrue(キャッシュファイル自体はあったが中身がなかった）のとき
    if fetched:
        #キャッシュファイルに先ほどurlから直接取ってきたデータを書き込む
        fp = file(cache_path, 'w')
        json.dump(data, fp)
        fp.close()

    #キャッシュファイルの中身のstatusがokでなかったらエラーを出す
    #キャッシュファイルの中身に関しては以下参照
    #https://qiita.com/oyuno_hito/items/69531fcc4b133dfea205
    #https://developers.google.com/maps/documentation/directions/intro
    #https://qiita.com/kngsym2018/items/15f19a88ea37c1cd3646
    if data.get('status') != 'OK':
        error('Bad data')

    #route->経路ごとに配列に詳細がjson形式で格納
    route = data['routes'][0]
    #route->legs->距離、時間、始点及び終点の住所と緯度経度、経路が格納
    return route['legs']

#polylineはエンコードされた形(例 :a~l~Fjk~uOwHJy@P)で格納されているためデコードする
def decodePoly(pts):
    step1 = [ord(x) - 63 for x in pts]

    step2, vals = [], []
    for val in step1:
        vals.insert(0, val & 0x1f)
        if val < 0x20:
            val = 0
            for n in vals:
                val = (val << 5) + n
            if val % 2: val = ~(val - 1)
            val /= 2.0
            val /= 100000.0

            step2.append(val)
            vals = []
    #デコード結果をstep3に（lat:(緯度), lng:(経度)）の形で格納する
    step3 = []
    for lat, lng in zip(step2[0::2], step2[1::2]):
        if len(step3) > 0:
            lat += step3[-1]['lat']
            lng += step3[-1]['lng']
        step3.append({'lat':lat, 'lng':lng})
    #step3を返す
    return step3

#
def getDistanceBetweenPoints(a, b):
    lat1 = radians(a['lat'])
    lng1 = radians(a['lng'])
    lat2 = radians(b['lat'])
    lng2 = radians(b['lng'])

    R = 6371.0 * 1000 # radius of earth by km

    a = pow(sin((lat1 - lat2) / 2.0), 2) + pow(sin((lng1 - lng2) / 2.0), 2) * cos(lat1) * cos(lat2)

    c = 2.0 * atan2(sqrt(a), sqrt(1.0 - a))

    return R * c # / 1.6 * 5280.0 # to mile, then to feet

#
def getRotationBetweenPoints(a, b):
    lat1    = radians(a['lat'])
    lat2    = radians(b['lat'])
    diffLng = radians(b['lng'] - a['lng'])

    x = sin(diffLng) * cos(lat2)
    y = cos(lat1) * sin(lat2) - (sin(lat1) * cos(lat2) * cos(diffLng))

    radian = atan2(x, y)
    degree = degrees(radian)
    return (degree + 360) % 360

#
def complementPoints(points, duration, distance):
    result = []
    # なめらかに遷移させるため両端のデータは切り落とす
    #配列の次の値と比較し続ける感じ(a:points[1] b:points[2]->a:points[2] b:points[3]...)
    #ただし両端は含めない（points[0],points[-1](一番後ろ))
    #pid = 0 #追加
    for a, b in zip(points[1:-2], points[2:-1]):
        #次のルートポイントまでの距離を求める
        dd = getDistanceBetweenPoints(a, b)
        #次のルートポイントまでの時間を求める
        dt = duration * (dd / distance)

        t = 0.0
        #次のルートポイントとの緯度の差を求める
        lat = b['lat'] - a['lat']
        #次のルートポイントとの経度の差を求める
        lng = b['lng'] - a['lng']
        #経過時間を1から最後まで1秒単位で見ていく
        while t < dt:
            #r=(今見ている時間/全体の経過時間)
            r = t / dt
            #時間単位での情報(1秒単位)
            pt = {
                    'lat'      : a['lat'] + lat * r, #現在の緯度
                    'lng'      : a['lng'] + lng * r, #現在の経度
                    'speed'    : int(dd * 100 / dt), # speed : centimeter / sec
                    'rotation' : getRotationBetweenPoints(a, b) * 10, #進む方向の変化（角度の変化）
                    #'pathid'   : pid #追加
            }
            #上記の情報を1秒単位で経過時間分全部配列resultに入れる
            result.append(pt)
            t += 1
        #pid += 1    #追加

#     result.append(points[-1])
    #resultを表示
    return result


def convertToComplementPoints(legs):
    result = []
    cnt = 0
    for leg in legs:
        #legsパラメータの中のstepsの中身を1つ1つ見る
        for step in leg['steps']:
            #startの中に'start_location'の情報を入れる(出発地の緯度経度情報が入ってる)
            start = step['start_location']
            #endの中に'end_location'の情報を入れる(目的地の緯度経度情報が入ってる)
            end = step['end_location']
            #durartionの中に'duration'の情報のうちの'value'を入れる(経過時間(s)が入っている)
            duration = step['duration']['value']
            #distanceの中に'distance'の情報のうちの'value'を入れる(距離(m)が入っている)
            distance = step['distance']['value']
            #なぜ2重で呼び出してるのか?
            decodePoly(step['polyline']['points'])
            #ルート上の点の情報をpointsに入れる(decodePolyを介すことで経路途中の点が"lat:(緯度),lng:(経度)"の形の文字列として格納されている配列になる)
            points = decodePoly(step['polyline']['points'])
            #points = decodePoly("}sstEuvr{XSou@kDBGqC{BH?uB{UN_@sJ")
            #配列pointsの最初に出発地の緯度経度情報を挿入する
            points.insert(0, start)
            #配列pointsの最後に目的地の緯度経度情報を挿入する
            points.append(end)
            #completementPointsを実行、秒単位での経路情報（緯度、経度、進行方向、速度、パス名)をresultに追加
            cnt += 1
            result.extend(complementPoints(points, duration, distance))
    return result

#
def addRotation(points):
    for point1, point2 in zip(points[0:-1], points[1:]):
        point1['rotation'] = getRotationBetweenPoints(point1, point2) * 10
    points[-1]['rotation'] = points[-2]['rotation']
    return points

#
def output(sid, steps, rpath):
    #OUTPUTDIR(GooleDirectionData)がなかったらそのディレクトリを作る
    if not os.path.isdir("./" + OUTPUT_DIR):
        os.makedirs(OUTPUT_DIR)
    if not os.path.isdir("./" + OUTPUT_DIR2):
        os.makedirs(OUTPUT_DIR2)
    
    
    #%04dは4桁の10進数の意味
    #OUTPUTDIRのファイルを開いて書き込み（sid.txtの形で)
    f = open("./" + OUTPUT_DIR + "/%04d.txt" % sid, 'w')
    #経路ポイントの書き込み（緯度   経度    角度    速度)の形で
    for step in steps:
        #pow()->べき乗
        step['lat'] = int(step['lat'] * pow(10, 6))
        step['lng'] = int(step['lng'] * pow(10, 6))
        line = '%(lat)d\t%(lng)d\t%(rotation)d\t%(speed)d\n' % step
        #line = '%(lat)d\t%(lng)d\t%(rotation)d\t%(speed)d\t%(pathid)d\n' % step
        f.write(line)
    f.close()
    #経由ノードの保存（ルート）
    f2 = open("./" + OUTPUT_DIR2 + "/%04d.txt" % sid, 'w')
    for route in rpath:
        #pow()->べき乗
        route['slat'] = int(route['slat'] * pow(10, 6))
        route['slng'] = int(route['slng'] * pow(10, 6))
        route['glat'] = int(route['glat'] * pow(10, 6))
        route['glng'] = int(route['glng'] * pow(10, 6))
        line = '%(rid)d\t%(slat)d\t%(slng)d\t%(glat)d\t%(glng)d\t%(stime)d\t%(gtime)d\t%(polyline)s\n' % route
        #line = '%(lat)d\t%(lng)d\t%(rotation)d\t%(speed)d\t%(pathid)d\n' % step
        f2.write(line)
    f2.close()


# url    = createUrlForDirection("35.6639694,139.7206578", "35.6459722,139.6982763")
# legs   = fetchDirection(url)
# points = convertToComplementPoints(legs)
# for step in points:
#     step['lat'] = int(step['lat'] * pow(10, 6))
#     step['lng'] = int(step['lng'] * pow(10, 6))
#     print '%(lat)d\t%(lng)d\t%(rotation)d\t%(speed)d' % step


#車両ID
sid = 1
while(sid <= ID_CNT):
    #出発地（"緯度,経度")
    #origin = generateRandomLatLngStr()
    #origin = "35.003674,135.760587"
    #目的地("緯度,経度")
    #destination = generateRandomLatLngStr()
    #destination = "35.009445,135.772301"
    #"出発地の緯度,出発地の経度 => 目的地の緯度,目的地の経度"の出力
    #print ("%s => %s" % (origin, destination))
    #経路を得るためのurlの作成
    #url = createUrlForDirection(origin, destination)
    #url = "https://maps.googleapis.com/maps/api/directions/json?origin=35.003674,135.760587&destination=35.009445,135.772301&sensor=false&via:enc:etstEemt{XuDDGsC}BH?aBAS}EBmCBM@}@@u@?y@B}@@QA}A?:&key=AIzaSyCB2XZLd6qL68XM4Rxnby0KQYvwuI3KGTY"
    url = "https://maps.googleapis.com/maps/api/directions/json?origin=35.003674,135.760587&destination=35.009445,135.772301&sensor=false&optimizeWaypoints=true&waypoints=via:35.005872%2C135.769196&key=AIzaSyCB2XZLd6qL68XM4Rxnby0KQYvwuI3KGTY"
    try:
        #urlで返されたデータの中のlegsの情報(距離、時間、始点及び終点の住所と緯度経度、経路が格納)をlegsに入れる
        legs   = fetchDirection(url)
        #秒単位での経路情報（緯度、経度、速度、角度の変化)が入ってる配列をpointsに入れる
        points = convertToComplementPoints(legs)
        proute = generateroute.getRoutedata(legs)
        #print(str(sid)+":"+str(proute))
#         points  = addRotation(points)
        #OUTPUTDIR(GoogleDirectiondata)への経路ポイントの書き込み。（緯度   経度    角度    速度)の形で。
        #sidごとにtxtファイルを作成して書き込む
        output(sid, points, proute)
        sid += 1
    except:
        print("error")
        pass
#print 'done'
print("done")


