//
//  Const.swift
//  ldm-ios
//
//  Created by Ayakix on 2016/01/27.
//  Copyright © 2016年 Doshisha Univ. All rights reserved.
//

import SwiftyUserDefaults

let kEnableHTTPS = false
let kProtocolVersion = 1

// サーバー
let kHost = "180.8.8.187"
//let kHost = "192.168.100.171"
let kPort = "3000"
//let kHost = "172.20.69.187"



var kBaseUrl: String {
    get {
        let prot = kEnableHTTPS ? "https" : "http"
        let host = (Defaults.hasKey(.host)) ? Defaults[.host] : kHost;
        let port = (Defaults.hasKey(.port)) ? Defaults[.port] : kPort;
        return "\(prot)://\(host):\(port)/api/"
    }
}

var kPresentUrl: String {
    get {
        let prot = kEnableHTTPS ? "https" : "http"
        let host = (Defaults.hasKey(.host)) ? Defaults[.host] : kHost;
        let port = (Defaults.hasKey(.port)) ? Defaults[.port] : kPort;
        return "\(prot)://\(host):\(port)/present?tid=\(Defaults[.sid]!)"
    }
}

// レイアウト用マージン
let kMargin:CGFloat = 8.0

// 送信を停止する時間(秒)
let kTerminatingSeconds = 90.0 * 60.0
