var FRAME_PER_SEC = 10;
var map;
var json;
var camData;
var stationDic = {};
var timer;
var time;
var indexes = {};
var minUnixTime;
var maxUnixTime;
var selectedStart;
var selectedEnd;
var useCentralMode = true;
var alertCircle = null;
var useAlertCircle = true;

$(function(){
  // 警告モードの場合はデフォルトOFF
  if (isAlertMode) {
    $('#all-check').prop('checked', false);
  }
   //日付指定ピッカーの作成（past.ectのみ）
   //参考-> https://www.daterangepicker.com/
  $('input[name="daterange"]').daterangepicker({
    'timePicker'          : true,//日付に加えて時間を選択する選択ボックスを追加する
    'timePickerSeconds'   : true,//timePickerに秒を表示する
    'timePickerIncrement' : 1,//時間の分の選択リストの増加
    'timePicker24Hour'    : true,//AM / PMの選択を削除して、12時間ではなく24時間を使用する
    'startDate'           : start,//(日付または文字列）最初に選択された日付範囲の開始日。文字列を指定する場合、locale設定で設定されている日付形式文字列と一致する必要があります。
    'endDate'             : end,//（日付または文字列）最初に選択された日付範囲の終了日。
    //ボタンとラベルにローカライズされた文字列を提供し、日付形式をカスタマイズし、カレンダーの週の最初の曜日を変更できます。localeこれらのオプションをカスタマイズする方法については、構成ジェネレーターをチェックしてください。
    'locale': {
      //選択範囲の日付のフォーマット
        'format': 'YYYY/MM/DD HH:mm:ss'
    },
  }, function(start, end, label) {
    //toISOString->時刻のISO形式に変える
    //05 October 2011 14:48 UTC-> 2011-10-05T14:48:00.000Z
    selectedStart = start.toISOString();
    selectedEnd   = end.toISOString();
    //Cam情報の取得
    fetchCams(selectedStart, selectedEnd);
  });

  // startとendが指定されている場合には自動的に読み込む
  if (start != "2016-01-01T00:00:00Z" && end != "2016-01-01T00:00:00Z") {
    selectedStart = start;
    selectedEnd   = end;
    //Cam情報の取得
    fetchCams(selectedStart, selectedEnd);
  }
});

//選択された時間内のCam情報の取得
function fetchCams(startStr, endStr) {
  // console.log('fetch: from:' + startStr + ', to:' + endStr);
  // /api/cam/fetch に startStrとendStrと_dataのパラメータを加えたもののjsonを入手する（cam情報を手に入れる)(/route/api.js)
  $.getJSON("/api/cam/fetch?from=" + startStr + "&to=" + endStr, function(_json) {
    //jsonにはcam情報が入る
    json       = _json;
    stationDic = json['stations'];
/*
    'stations'    : {sid : 'station'         :    sid:
                                                  sname:
                           'stype'           : cam.stype,
                           'protocolVersion' : cam.protocolVersion,
                           'steps'           : [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               .
                                               .
                                               .
                     sid :  
                      .
                      .
                      .
                    }
*/
    //StationDicの中身がなかったら
    if (Object.keys(stationDic).length == 0) {
      alert('指定期間にはデータがありませんでした。');
      return;
    }
   
    minUnixTime = json['minUnixTime'];
    maxUnixTime = json['maxUnixTime'];
    //マップの境界の設定とその境界がうまく写るように設定(common.js)
    fitBoundsForMap(map, json['minLat'], json['maxLat'], json['minLng'], json['maxLng']);
    //初期状態にリセットする
    initState();
    //cam情報に沿ってマーカーと経路オブジェクとを作成してstationDicに追加する
    initSymbols();
  });
}

//リセット
function initState() {
  // ボタンを再生可能状態に
  $("#play").prop("disabled", false);
  //refreshの"disabled"をtrueにする
  $("#refresh").prop("disabled", true);

  time = minUnixTime;
  //時刻の更新
  updateClock();
}

//時刻の更新
function updateClock() {
  var d = new Date(time + 1000 * 60 * 60 * 9);
  var dateStr = d.toISOString();
  dateStr = dateStr.replace("T", " ").substring(0, dateStr.length - 3)
  $("#clock").text(dateStr);
}

//cam情報に沿ってマーカーと経路オブジェクとを作成してstationDicに追加する
function initSymbols() {
  //すべてのsidに対して
  for(sid in stationDic){
    //色をランダムに決める
    var color = getRandomColor();
    var cam = stationDic[sid];

    // 警告モードでかつ、ターゲットステーションの場合は、別表示にする
    if (isAlertMode && sid == tid) {
      //色を赤にする
      color = 'red';
      //target-stationの表示と更新
      addTargetStationElem(cam.station.sname, cam.stype, sid, color);
    } else {
      //checkboxの作成と更新
      // 凡例チェックボックス
      // 警告モードの場合は全てチェックを外す(警告対象にする)
      addCheckboxElem(cam.station.sname, cam.stype, sid, !isAlertMode, color);
    }

    // マーカーの作成
    marker = makeMarker(map, sid, cam.stype);
    stationDic[sid]['marker'] = marker;
    // ライン
    stationDic[sid]['line']  = makeLine(map, cam.steps, color);
  }
}

//色をランダムに決める
function getRandomColor() {
  var letters = '0123456789ABCDEF'.split('');
  var color = '#';
  for (var i = 0; i < 6; i++ ) {
      color += letters[Math.floor(Math.random() * letters.length)];
  }
  return color;
}


function displayStep(sid, step) {
  //if(!isChecked(sid)) return;
  var cam = stationDic[sid];
  //マーカーの作成
  var marker = cam.marker;
  //マーカーアイコンの設定（警告時や通常時、タイプ）(common.js)
  setIconForMarker(marker, cam.stype, step.lat, step.lng, step.rotation, step.speed);
}
/*
                     sid : 'station'         :    sid:
                                                  sname:
                           'stype'           : cam.stype,
                           'protocolVersion' : cam.protocolVersion,
                           'steps'           : [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               [
                                                 'date'     : cam.date,
                                                 'unixTime' : unixTime,
                                                 'lat'      : convertedLat,
                                                 'lng'      : convertedLng,
                                                 'rotation' : convertedRotation,
                                                 'speed'    : convertedSpeed,
                                               ],
                                               .
                                               .
                                               .
 */

 //play
function play() {
  //ステーションのチェックしているすべてのマーカーを設置(common.js)
  setMapForMarkers(stationDic);
  //すべての線の削除(common.js)
  removeAllLines(stationDic);

  // 中心モードの場合は、地図のズームレベルを変更
  if (isAlertMode && useCentralMode) {
    map.setZoom(19)
  }
  //stationDicの中身を配列に入れる(sidが入る)
  var sortedSIDs = Object.keys(stationDic);
  // 警告モードの時には、tidとして指定されているステーションidを配列の先頭に持ってくる.
  // tid == 6
  // sort前=["1", "2", "3", "4", "5", "6"]
  // sort後=["6", "5", "3", "1", "4", "2"]
  //警告モードの時
  if (isAlertMode) {
    //sortedSIDのsidをソートする
    sortedSIDs.sort(
      //tidは先頭にする
        function(a, b) {
          if( a == tid ) return -1;
          return 1;
        }
    );
  }

  var tLat, tLng;
  var alertStations     = [];
  var dangerousStations = [];
  //一定時間ごとに特定の処理を繰り返す
  timer = setInterval(function() {
    // console.log("time:" + time);
    //選択したspeedの値をdiffに入れる
    var diff = parseInt($("input[name='speed']:checked").val()) / FRAME_PER_SEC;
    /*
    <h3>表示設定</h3>
    <div id="speeds" class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
      <label>
        ・再生速度(秒)
        <input type="radio" name="speed" value="1000" checked> x1
        <input type="radio" name="speed" value="2000"> x2
        <input type="radio" name="speed" value="5000"> x5
        <input type="radio" name="speed" value="10000"> x10
      </label>
    </div>
    */
    //時刻のアップデート
    updateClock();

    //ソートされたid順にすべて見る
    for(var i = 0; i < sortedSIDs.length; i++) {
      var sid   = sortedSIDs[i];
      var steps = stationDic[sid]['steps'];

      var lastIndex = 0;
      //indexesの中にsidがあったら
      if (sid in indexes) {
        lastIndex = indexes[sid];
      }
//lastIndexがstepの数より大きかったら飛ばす
      if(lastIndex >= steps.length) {
        continue;
      }
      //stepにstepsのlastIndex番目を入れる
      var step = steps[lastIndex];
      //time -> minunixtime
      //unixtime <- stepができた時刻
      if(time - diff < step.unixTime && step.unixTime <= time) {
        // console.log(sid + " " + time + " " + step.lat + " " + step.lng + " " + step.rotation);
        //マーカーアイコンの設定
        displayStep(sid, step);

        //アラートモードの時
        if (isAlertMode) {
          //sidがtidと同じ時
          if (sid == tid) {
            tLat = step.lat;
            tLng = step.lng;
            var tLatLng = new google.maps.LatLng(tLat, tLng);
            // 中心モードの場合は、地図の中心を更新
            // setCenterを使うとマーカーが途中から消えるバグがあるので注意
            // https://code.google.com/p/gmaps-api-issues/issues/detail?id=5716
            if (useCentralMode) {
              map.panTo(tLatLng);
            }
            // 警告範囲の表示がオンの時
            if (useAlertCircle) {
              //alertCircleがない時alertCircleの作成
              if (alertCircle == null) {
                alertCircle = makeAlertCircle(map);
              }
              //tLatLngを中心に設定
              alertCircle.setCenter(tLatLng);
              オフの時
            } else {
              //0,0を中心に設定
              alertCircle.setCenter(new google.maps.LatLng(0, 0));
            }
          } else {
            // 距離を算出し、必要に応じてアラートを出す
            // アラートを出す必要がない場合は、リストから消す
            handleAlert(sid, step.lat, step.lng, tLat, tLng, alertStations, dangerousStations);
          }
        }

        // 同一区間内に複数データがある場合には飛ばす
        while(time - diff < step.unixTime && step.unixTime <= time) {
          lastIndex++;
          // 描画を終了
          //lastIndexがsteps長さより大きい時（経路の終了）
          if(lastIndex >= steps.length) {
            // そのidをマーカーを地図上から消す
            removeMarker(stationDic, sid);
            // 距離表示を消す
            $('#distance-' + sid).empty();
            $('#distance-' + sid).removeAttr("style");
            // 警告表示を消す
            if (alertStations.indexOf(sid) >= 0) {
              alertStations.splice(alertStations.indexOf(sid), 1);
            }
            if (dangerousStations.indexOf(sid) >= 0) {
              dangerousStations.splice(dangerousStations.indexOf(sid), 1);
            }
            break;
          }
          step = steps[lastIndex];
          //stepの長さを格納?
          indexes[sid] = lastIndex;
        }
      }
    }

    if (isAlertMode) {
      // アラートを表示する
      displayAlert(alertStations);
    }

    time += diff;
    // 再生終了時
    if (time > maxUnixTime) {
      // 描画を終了し、全てのマーカーを地図上から消す
      removeAllMarkers(stationDic);
      $("#play").prop("disabled", true);
      pause();
    }
  }, 1000 / FRAME_PER_SEC);
}

function pause() {
  //setinterbalを停止
  clearInterval(timer);
  //refreshのdisabledの値をfalseにする
  $("#refresh").prop("disabled", false);
}

//id属性がcheckbox-と先頭一致
//https://qiita.com/Thought_Nibbler/items/5d4fc40a4d4325128b24
//common->addCheckboxElem
$(document).on("change", "[id^=checkbox-]", function() {
  // チェックボックスの値に基づいてマーカーとラインを再描画する(地図に設置)
  setMapForMarker(stationDic, $(this).attr('sid'));
  // 再生中はラインを再描画しない（表示しない）
  if (!$("#play").hasClass("playing")) {
    setMapForLine(stationDic, $(this).attr('sid'));
  }
});

//中心描画モードに変化があったら
$('#use-central-mode').on("change", function() {
  useCentralMode = $(this).is(':checked');
  if (useCentralMode) {
    map.setZoom(MAX_ZOOM_LEVEL);
  } else {
    fitBoundsForMap(map, json['minLat'], json['maxLat'], json['minLng'], json['maxLng']);
  }
});

//警告表示に変化があったら
$('#use-alert-circle').on("change", function() {
  useAlertCircle = $(this).is(':checked');
});

//再生がクリックされたら
$("#play").on("click", function() {
  $(this).toggleClass("playing");
  $(this).toggleClass("btn-info");
  $(this).empty();

  if ($(this).hasClass("playing")) {
    $(this).append('<span class="glyphicon glyphicon-pause"></span> Pause');
    play();
    $("#refresh").prop("disabled", true);
  } else {
    $(this).append('<span class="glyphicon glyphicon-play"></span> Play');
    pause();
    $("#refresh").prop("disabled", false);
  }
});

//リフレッシュがクリックされたら
$("#refresh").on("click", function(){
  pause();

  // 時刻とtidを引き継いだ状態でリロード
  var url = "?start=" + selectedStart + "&end=" + selectedEnd;
  if (isAlertMode) {
    url += "&tid=" + tid;
  }
  location.href = url;
});

//地図描画の実行(initMap(commomn.js)の呼び出し)
google.maps.event.addDomListener(window, 'load', initMap);

